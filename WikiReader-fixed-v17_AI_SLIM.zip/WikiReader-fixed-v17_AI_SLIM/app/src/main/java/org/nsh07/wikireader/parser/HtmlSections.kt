package org.nsh07.wikireader.parser

/**
 * Splits the HTML returned by Wikipedia's REST `page/html` endpoint into the same
 * `[intro, heading, body, heading, body, ...]` shape that [org.nsh07.wikireader.data.parseSections]
 * produces for wikitext.
 *
 * Only top-level `h2` headings become sections. Everything readable stays in the body (paragraphs,
 * lists, links, tables, captions and reference lists), while Wikipedia chrome that has no place in
 * a reader (scripts, edit links, infoboxes, navigation boxes, maintenance banners and raw metadata)
 * is removed first.
 *
 * The sanitizer intentionally uses a small quote-aware scanner instead of regular expressions for
 * elements. REST HTML puts raw `>` characters inside `data-mw` attributes; regex-based tag matching
 * stops at those characters and can leak template/citation source into the article or truncate the
 * following prose. The scanner also removes nested chrome as one balanced element.
 *
 * This is plain Kotlin so it can be unit tested on the JVM and runs off the main thread.
 */
private val headingRegex = Regex("(?is)<h2\\b[^>]*>(.*?)</h2\\s*>")
private val tagRegex = Regex("(?s)<[^>]+>")
private val entityRegex = Regex("&(#x?[0-9a-fA-F]+|[a-zA-Z]+);")
private val hrefRegex = Regex("(?i)href\\s*=\\s*\"([^\"]*)\"")
private val manyNewlinesRegex = Regex("\\n[ \\t]*\\n(?:[ \\t]*\\n)+")
private val classAttrRegex =
    Regex("(?is)\\bclass\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s>]+))")
private val hrefAttrRegex =
    Regex("(?is)\\bhref\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s>]+))")
private val resourceAttrRegex =
    Regex("(?is)\\bresource\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s>]+))")
private val srcAttrRegex =
    Regex("(?is)\\bsrc\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s>]+))")
private val widthAttrRegex =
    Regex("(?is)\\bwidth\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s>]+))")
private val typeofAttrRegex =
    Regex("(?is)\\btypeof\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s>]+))")
private val styleAttrRegex =
    Regex("(?is)\\bstyle\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s>]+))")
private val imgTagRegex = Regex("(?is)<img\\b[^>]*>")
private val figcaptionRegex = Regex("(?is)<figcaption\\b[^>]*>(.*?)</figcaption\\s*>")
private val imageExtensionRegex =
    Regex(".+\\.(jpe?g|png|gif|svg|webp|tiff?|bmp|jfif|apng)$", RegexOption.IGNORE_CASE)

/** Elements whose entire content is not article text. */
private val droppedTags = setOf(
    "style", "script", "noscript", "link", "meta", "img", "input", "wbr", "iframe",
    "audio", "video", "source", "track", "object", "embed", "annotation", "svg"
)

/** HTML void elements: an opening tag has no matching closing tag. */
private val voidTags = setOf(
    "area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta",
    "param", "source", "track", "wbr"
)

/** Class tokens that mark chrome rather than readable article content. */
private val removedClasses = setOf(
    "navbox", "vertical-navbox", "navbox-styles", "infobox", "sidebar", "metadata",
    "ambox", "tmbox", "hatnote", "shortdescription", "mw-empty-elt", "noprint",
    "mw-editsection", "mw-hidden-catlinks", "mw-indicators", "printfooter", "catlinks"
)

private val inlineTags = setOf(
    "b", "strong", "i", "em", "u", "s", "strike", "del", "ins", "sub", "sup",
    "code", "tt", "kbd", "samp", "var", "small", "big", "cite", "q"
)

private val blockTags = setOf(
    "blockquote", "p", "ul", "ol", "li", "dl", "dt", "dd", "pre", "table",
    "thead", "tbody", "tfoot", "tr", "td", "th", "caption", "h2", "h3", "h4", "h5", "h6"
)

/** Layout-only wrappers: drop the tag but keep the text and block boundaries. */
private val wrapperTags = setOf(
    "div", "section", "figure", "figcaption", "header", "footer", "article", "aside",
    "main", "nav"
)

private data class HtmlTag(
    val name: String,
    val closing: Boolean,
    val selfClosing: Boolean,
    val attributes: String
)

/**
 * @return alternating intro/heading/body strings. The first element is always the intro (possibly
 * empty). Every heading is plain text; every body is sanitised HTML.
 */
fun splitHtmlSections(html: String): List<String> {
    val content = extractContent(html)
    // Lift pictures out before sanitise() deletes every <img>. They are re-emitted as ordinary
    // `[[File:…|caption]]` lines, which ImageWithCaption draws exactly like wikitext pictures.
    val withMedia = extractHtmlMediaBlocks(content)
    val cleaned = sanitise(withMedia)

    val allHeadings = headingRegex.findAll(cleaned).toList()
    // Ignore empty h2 elements. They used to be treated as a section boundary and then skipped,
    // which silently threw away all text up to the next heading.
    val headings = allHeadings.filter { plainText(it.groupValues[1]).isNotBlank() }
    if (headings.isEmpty()) return listOf(tidy(cleaned))

    val out = ArrayList<String>(headings.size * 2 + 1)
    // Keep everything before the first *readable* heading, including text between ignored empty
    // headings and real prose.
    out.add(tidy(cleaned.substring(0, headings.first().range.first)))

    headings.forEachIndexed { index, match ->
        val heading = plainText(match.groupValues[1])
        val bodyEnd = headings.getOrNull(index + 1)?.range?.first ?: cleaned.length
        val body = tidy(cleaned.substring(match.range.last + 1, bodyEnd))
        out.add(heading)
        out.add(body)
    }

    // A page with no readable h2 still needs a valid intro slot.
    if (out.isEmpty()) out.add("")
    return out
}

private fun extractContent(html: String): String {
    val bodyStart = html.indexOf("<body", ignoreCase = true)
    val content = if (bodyStart >= 0) {
        val openEnd = html.indexOf('>', bodyStart).let { if (it < 0) html.length else it + 1 }
        val bodyEnd = html.lastIndexOf("</body", ignoreCase = true).let { if (it < 0) html.length else it }
        html.substring(openEnd.coerceAtMost(bodyEnd), bodyEnd)
    } else html

    // REST HTML usually puts `mw-parser-output` on <body>, which is already stripped above. Some
    // responses instead wrap the article in a <div class="mw-parser-output">. Find that class in an
    // actual opening tag: `mw-parser-output` also appears inside inline <style> CSS blocks (for
    // example the citation styles at the end of an article). Searching the raw string for the class
    // name used to enter one of those CSS blocks and throw away every section before References.
    val wrapper = findParserOutputRange(content) ?: return content
    return content.substring(wrapper.first, wrapper.last + 1)
}

// ---------------------------------------------------------------------------
// Pictures in REST HTML
// ---------------------------------------------------------------------------

/**
 * Replaces picture markup with the `[[File:…|caption]]` blocks the article renderer already
 * draws. Called before [sanitise], because the sanitiser removes `<img>` (Compose's HTML parser
 * cannot display it) and removes the whole infobox. Without this pass HTML mode showed no
 * in-article pictures at all — only the API page image, which has no caption.
 *
 * Handles the three shapes REST HTML uses:
 *  - `<figure typeof="mw:File/Thumb"> … <figcaption>…</figcaption></figure>` (body pictures),
 *  - `<table class="infobox …">` with `<img resource="./File:X.jpg">` plus the small caption
 *    cell below each picture,
 *  - `<ul class="gallery">` with one `<li class="gallerybox">` per picture.
 */
private fun extractHtmlMediaBlocks(html: String): String {
    if (!html.contains("<figure", ignoreCase = true) &&
        !html.contains("class=\"gallery", ignoreCase = true) &&
        !html.contains("<img", ignoreCase = true)
    ) return html

    val out = StringBuilder(html.length)
    var i = 0
    while (i < html.length) {
        val start = html.indexOf('<', i)
        if (start < 0) {
            out.append(html, i, html.length)
            break
        }
        if (start > i) out.append(html, i, start)
        if (html.startsWith("<!--", start)) {
            val commentEnd = html.indexOf("-->", start + 4)
            val end = if (commentEnd < 0) html.length else commentEnd + 3
            out.append(html, start, end)
            i = end
            continue
        }
        val end = findTagEnd(html, start)
        if (end < 0) {
            out.append(html, start, html.length)
            break
        }
        val tag = parseTag(html.substring(start, end + 1))
        if (tag == null || tag.closing || tag.selfClosing || tag.name in voidTags) {
            out.append(html, start, end + 1)
            i = end + 1
            continue
        }
        val classes = classTokens(tag.attributes)
        val isInfobox = tag.name == "table" && "infobox" in classes
        val isFigure = tag.name == "figure"
        val isGallery = "gallery" in classes &&
                (tag.name == "ul" || tag.name == "div" || tag.name == "table")
        // `div.thumb` (one picture + thumbcaption) and `div.tmulti` ({{Multiple image}}) hold
        // their caption beside/under the pictures. Treat the whole container as one unit so a
        // caption cannot be paired with a picture from the next block.
        val isThumbDiv = tag.name == "div" && ("thumb" in classes || "tmulti" in classes)
        val isFileSpan = tag.name == "span" &&
                "noviewer" !in classes &&
                attributeValue(tag.attributes, typeofAttrRegex)
                    .orEmpty().startsWith("mw:File", ignoreCase = true)

        if (isInfobox || isFigure || isGallery || isThumbDiv) {
            val close = findMatchingClose(html, end + 1, tag.name)
            if (close >= 0) {
                val media = htmlMediaLines(
                    html.substring(start, close + 1),
                    gallery = isGallery
                )
                if (media.isNotEmpty()) {
                    out.append('\n').append(media.joinToString("\n")).append('\n')
                }
                i = close + 1
                continue
            }
        } else if (isFileSpan) {
            val close = findMatchingClose(html, end + 1, tag.name)
            if (close >= 0) {
                val media = htmlMediaLines(
                    html.substring(start, close + 1),
                    gallery = false
                )
                if (media.isNotEmpty()) {
                    out.append('\n').append(media.joinToString("\n")).append('\n')
                }
                i = close + 1
                continue
            }
        }
        out.append(html, start, end + 1)
        i = end + 1
    }
    return out.toString()
}

/** Splits a sanitised HTML chunk into ordinary HTML and `[[File:…]]` picture blocks. */
fun splitHtmlMediaBlocks(html: String): List<String> {
    if (!html.contains("[[File:", ignoreCase = true)) return listOf(html)
    val out = ArrayList<String>()
    val text = StringBuilder()
    for (line in html.lineSequence()) {
        if (line.trimStart().startsWith("[[File:", ignoreCase = true)) {
            if (text.isNotBlank()) out.add(text.toString())
            text.setLength(0)
            out.add(line.trim())
        } else {
            text.append(line).append('\n')
        }
    }
    if (text.isNotBlank()) out.add(text.toString())
    return out
}

private fun htmlMediaLines(fragment: String, gallery: Boolean): List<String> {
    val lines = ArrayList<String>()
    if (gallery) {
        for (item in directElements(fragment, "li")) {
            val img = imgTagRegex.find(item.inner) ?: continue
            val name = htmlImageName(img.value) ?: continue
            lines.add(pictureLine(name, htmlCaptions(item.inner).firstOrNull().orEmpty()))
        }
        if (lines.isNotEmpty()) return lines.distinct()
    }
    val captions = htmlCaptions(fragment)
    var index = 0
    for (img in imgTagRegex.findAll(fragment)) {
        val name = htmlImageName(img.value) ?: continue
        val caption = captions.getOrNull(index).orEmpty()
        index++
        lines.add(pictureLine(name, caption))
    }
    return lines.distinct()
}

/** File name from an `<img>` tag, preferring `resource` (a stable `File:` title). */
private fun htmlImageName(token: String): String? {
    var value = attributeValue(token, resourceAttrRegex)
        ?: attributeValue(token, srcAttrRegex)
        ?: return null
    var name = value.substringBefore('?').substringAfterLast('/').trim()
    name = runCatching { java.net.URLDecoder.decode(name, "UTF-8") }.getOrDefault(name)
    name = name.replace(Regex("^\\d+px-"), "").trim()
    if (name.startsWith("File:", true) || name.startsWith("Image:", true)) {
        name = name.substringAfter(':').trim()
    }
    if (!imageExtensionRegex.matches(name)) return null
    // Flags, logos, icons and maths sprites are not article pictures.
    val width = attributeValue(token, widthAttrRegex)?.toIntOrNull()
    if (width != null && width < 48) return null
    if (attributeValue(token, classAttrRegex)?.contains("noviewer", true) == true) return null
    return name
}

/**
 * Caption texts, in document order. `<figcaption>` wins; otherwise infobox caption cells and
 * gallery captions are collected.
 */
private fun htmlCaptions(fragment: String): List<String> {
    val out = ArrayList<String>()
    figcaptionRegex.findAll(fragment).forEach { match ->
        val text = plainText(match.groupValues[1])
        if (text.isNotBlank()) out.add(text)
    }
    if (out.isNotEmpty()) return out

    var i = 0
    while (i < fragment.length) {
        val start = fragment.indexOf('<', i)
        if (start < 0) break
        val end = findTagEnd(fragment, start)
        if (end < 0) break
        val tag = parseTag(fragment.substring(start, end + 1))
        if (tag == null || tag.closing || tag.selfClosing || tag.name in voidTags) {
            i = end + 1
            continue
        }
        val classes = classTokens(tag.attributes)
        val style = attributeValue(tag.attributes, styleAttrRegex).orEmpty()
        val looksCaption = classes.any { it.contains("caption") || it == "gallerytext" } ||
                style.contains("font-size: 88%", ignoreCase = true)
        if (!looksCaption) {
            i = end + 1
            continue
        }
        val close = findMatchingClose(fragment, end + 1, tag.name)
        if (close < 0) {
            i = end + 1
            continue
        }
        // findMatchingClose returns the '>' of the closing tag; exclude the tag itself.
        val closeTagStart = fragment.lastIndexOf('<', close)
        val text = plainText(fragment.substring(end + 1, closeTagStart))
            .replace(Regex("\\s+([,.;:!?])"), "$1")
        if (text.isNotBlank()) out.add(text)
        i = close + 1
    }
    return out
}

private fun pictureLine(name: String, caption: String): String {
    val clean = caption
        .replace("]]", "")
        .replace('|', '/')
        .replace('\n', ' ')
        .replace(Regex("\\s+([,.;:!?])"), "$1")
        .trim()
    return "[[File:$name|$clean]]"
}

/** Inner range of the first real element carrying the `mw-parser-output` class. */
private fun findParserOutputRange(html: String): IntRange? {
    var i = 0
    while (i < html.length) {
        val tagStart = html.indexOf('<', i)
        if (tagStart < 0) return null
        if (html.startsWith("<!--", tagStart)) {
            val commentEnd = html.indexOf("-->", tagStart + 4)
            i = if (commentEnd < 0) html.length else commentEnd + 3
            continue
        }
        val tagEnd = findTagEnd(html, tagStart)
        if (tagEnd < 0) return null
        val tag = parseTag(html.substring(tagStart, tagEnd + 1))
        if (tag != null && !tag.closing && !tag.selfClosing &&
            "mw-parser-output" in classTokens(tag.attributes)
        ) {
            val close = findMatchingClose(html, tagEnd + 1, tag.name)
            val end = if (close < 0) html.length - 1 else close - 1
            return (tagEnd + 1)..end
        }
        i = tagEnd + 1
    }
    return null
}

/**
 * Removes non-reader markup while preserving ordinary prose and nested structure.
 *
 * The scanner finds the end of a tag by respecting quoted attribute values, so `>` inside
 * `data-mw` is not mistaken for the end of the tag. Chrome elements are removed with balanced
 * closing-tag matching, which keeps nested infoboxes/sidebars from swallowing prose that follows
 * them.
 */
private fun sanitise(html: String): String {
    val out = StringBuilder(html.length)
    var i = 0
    while (i < html.length) {
        val tagStart = html.indexOf('<', i)
        if (tagStart < 0) {
            out.append(html, i, html.length)
            break
        }
        if (tagStart > i) out.append(html, i, tagStart)

        if (html.startsWith("<!--", tagStart)) {
            val commentEnd = html.indexOf("-->", tagStart + 4)
            i = if (commentEnd < 0) html.length else commentEnd + 3
            continue
        }

        val tagEnd = findTagEnd(html, tagStart)
        if (tagEnd < 0) {
            out.append(html, tagStart, html.length)
            break
        }

        val tag = parseTag(html.substring(tagStart, tagEnd + 1))
        if (tag == null) {
            // Doctype / processing instruction / malformed token.
            i = tagEnd + 1
            continue
        }

        if (shouldRemove(tag)) {
            if (tag.closing || tag.selfClosing || tag.name in voidTags) {
                i = tagEnd + 1
                continue
            }
            val close = findMatchingClose(html, tagEnd + 1, tag.name)
            if (close >= 0) {
                out.append('\n')
                i = close + 1
            } else {
                // Malformed or unclosed chrome: drop only its opening tag. Keeping the rest of the
                // page is more important than showing an unclosed navigation box.
                i = tagEnd + 1
            }
            continue
        }

        appendNormalized(out, tag)
        i = tagEnd + 1
    }
    return out.toString()
}

/** Index of the `>` that ends a tag, ignoring `>` inside quoted attribute values. */
private fun findTagEnd(html: String, start: Int): Int {
    var quote = '\u0000'
    var i = start + 1
    while (i < html.length) {
        val c = html[i]
        if (quote != '\u0000') {
            if (c == quote) quote = '\u0000'
        } else {
            when (c) {
                '"', '\'' -> quote = c
                '>' -> return i
            }
        }
        i++
    }
    return -1
}

private fun parseTag(token: String): HtmlTag? {
    if (token.length < 3 || token[0] != '<' || token[1] == '!' || token[1] == '?') return null

    var i = 1
    var closing = false
    if (token[i] == '/') {
        closing = true
        i++
    }
    while (i < token.length - 1 && token[i].isWhitespace()) i++

    val nameStart = i
    while (i < token.length - 1) {
        val c = token[i]
        if (c.isLetterOrDigit() || c == ':' || c == '-' || c == '_') i++ else break
    }
    if (i == nameStart) return null

    val name = token.substring(nameStart, i).lowercase()
    val selfClosing = !closing && token.length >= 2 && token[token.length - 2] == '/'
    val attributes = if (closing) "" else token.substring(i, token.length - 1)
    return HtmlTag(name, closing, selfClosing, attributes)
}

private fun attributeValue(attributes: String, regex: Regex): String? {
    val match = regex.find(attributes) ?: return null
    return match.groupValues[1]
        .ifEmpty { match.groupValues[2] }
        .ifEmpty { match.groupValues[3] }
}

private fun classTokens(attributes: String): Set<String> {
    val value = attributeValue(attributes, classAttrRegex) ?: return emptySet()
    return value.split(Regex("\\s+"))
        .filter { it.isNotEmpty() }
        .mapTo(HashSet()) { it.lowercase() }
}

private fun shouldRemove(tag: HtmlTag): Boolean {
    if (tag.closing) return false
    if (tag.name in droppedTags) return true
    val classes = classTokens(tag.attributes)
    if (classes.any { it in removedClasses }) return true
    return tag.name == "sup" && "reference" in classes
}

/** Finds the closing tag matching an already-consumed opening tag, honouring nested tags. */
private fun findMatchingClose(html: String, from: Int, name: String): Int {
    var depth = 1
    var i = from
    while (i < html.length) {
        val tagStart = html.indexOf('<', i)
        if (tagStart < 0) return -1

        if (html.startsWith("<!--", tagStart)) {
            val commentEnd = html.indexOf("-->", tagStart + 4)
            if (commentEnd < 0) return -1
            i = commentEnd + 3
            continue
        }

        val tagEnd = findTagEnd(html, tagStart)
        if (tagEnd < 0) return -1
        val tag = parseTag(html.substring(tagStart, tagEnd + 1))
        if (tag != null && tag.name == name && !tag.selfClosing) {
            if (tag.closing) {
                depth--
                if (depth == 0) return tagEnd
            } else {
                depth++
            }
        }
        i = tagEnd + 1
    }
    return -1
}

private fun appendNormalized(out: StringBuilder, tag: HtmlTag) {
    val name = tag.name
    when {
        name == "a" -> {
            if (tag.closing) {
                out.append("</a>")
            } else {
                val href = attributeValue(tag.attributes, hrefAttrRegex)
                if (href == null) out.append("<a>")
                else out.append("<a href=\"").append(href).append("\">")
            }
        }
        name == "br" -> if (!tag.closing) out.append("<br>")
        name == "hr" -> if (!tag.closing) out.append('\n')
        name in inlineTags || name in blockTags -> {
            if (tag.closing) out.append("</").append(name).append('>')
            else {
                out.append('<').append(name)
                // Keep the class on tables and cells: Wikipedia's phylogenetic trees are ordinary
                // <table class="clade"> blocks, and the HTML reader turns them back into a
                // Cladogram. Other attributes (including inline CSS) are still dropped.
                if (name == "table" || name == "td" || name == "th") {
                    val rawClass = attributeValue(tag.attributes, classAttrRegex)
                    if (!rawClass.isNullOrBlank()) {
                        out.append(" class=\"").append(rawClass).append('"')
                    }
                }
                out.append('>')
            }
        }
        name in wrapperTags -> out.append('\n')
        // Unknown tags are ignored, but their text content is kept.
    }
}

private fun tidy(html: String): String =
    html.replace(manyNewlinesRegex, "\n\n").trim()

/**
 * REST HTML uses relative links (`/wiki/Foo`). Compose's HTML parser keeps them as-is, and an
 * Android intent cannot open a relative URI. Make them absolute for [lang] before parsing.
 */
fun absolutizeHtmlLinks(html: String, lang: String): String = hrefRegex.replace(html) { match ->
    val href = match.groupValues[1]
    val absolute = when {
        href.startsWith("//") -> "https:$href"
        href.startsWith("/wiki/") -> "https://$lang.wikipedia.org$href"
        href.startsWith("./") -> "https://$lang.wikipedia.org/wiki/" + href.removePrefix("./")
        // A bare fragment (`#cite_note-1`) has no scheme and Android's intent handler
        // cannot open it. Point it at the wiki's main page instead of letting Text crash.
        href.startsWith("#") -> "https://$lang.wikipedia.org/wiki/"
        else -> href
    }
    "href=\"$absolute\""
}

/**
 * Splits a sanitised HTML section into ordinary HTML chunks and phylogenetic trees.
 *
 * Wikipedia renders `{{Clade}}` as nested `<table class="clade">` elements. Compose's
 * `AnnotatedString.fromHtml` silently drops tables, so a plant article in HTML mode lost its
 * tree entirely. Each clade table is converted back to the small `{{clade|...}}` syntax that
 * [org.nsh07.wikireader.ui.homeScreen.Cladogram] already draws, and the rest stays HTML.
 */
fun splitHtmlCladeBlocks(html: String): List<String> {
    val out = ArrayList<String>()
    var i = 0
    while (i < html.length) {
        val tableStart = findNextCladeTable(html, i)
        if (tableStart < 0) {
            if (i < html.length) out.add(html.substring(i))
            break
        }
        if (tableStart > i) out.add(html.substring(i, tableStart))
        val tagEnd = findTagEnd(html, tableStart)
        val close = if (tagEnd < 0) -1 else findMatchingClose(html, tagEnd + 1, "table")
        if (tagEnd < 0 || close < 0) {
            out.add(html.substring(tableStart))
            break
        }
        val tableHtml = html.substring(tableStart, close + 1)
        out.add(htmlCladeToWikitext(tableHtml) ?: tableHtml)
        i = close + 1
    }
    return out.filter { it.isNotBlank() }
}

private data class HtmlElement(val attributes: String, val inner: String)

/** First `<table class="clade">` at or after [from], or -1. */
private fun findNextCladeTable(html: String, from: Int): Int {
    var i = from
    while (i < html.length) {
        val start = html.indexOf("<table", i, ignoreCase = true)
        if (start < 0) return -1
        val end = findTagEnd(html, start)
        if (end < 0) return -1
        val tag = parseTag(html.substring(start, end + 1))
        if (tag != null && !tag.closing && "clade" in classTokens(tag.attributes)) return start
        i = end + 1
    }
    return -1
}

/**
 * Direct [name] children of [html], descending through wrappers such as `<tbody>` but never into a
 * nested `<table>` (the leaf cells contain the child clades).
 */
private fun directElements(html: String, name: String): List<HtmlElement> {
    val out = ArrayList<HtmlElement>()
    var i = 0
    while (i < html.length) {
        val start = html.indexOf('<', i)
        if (start < 0) break
        if (html.startsWith("<!--", start)) {
            val commentEnd = html.indexOf("-->", start + 4)
            i = if (commentEnd < 0) html.length else commentEnd + 3
            continue
        }
        val end = findTagEnd(html, start)
        if (end < 0) break
        val tag = parseTag(html.substring(start, end + 1))
        if (tag == null || tag.closing || tag.selfClosing || tag.name in voidTags) {
            i = end + 1
            continue
        }
        if (tag.name == name) {
            val close = findMatchingClose(html, end + 1, name)
            if (close < 0) {
                out.add(HtmlElement(tag.attributes, html.substring(end + 1)))
                break
            }
            // findMatchingClose returns the index of the closing tag's '>'. Exclude the whole
            // `</td>`/`</tr>`, otherwise it becomes visible text in the generated clade template.
            val closeTagStart = html.lastIndexOf('<', close)
            out.add(HtmlElement(tag.attributes, html.substring(end + 1, closeTagStart)))
            i = close + 1
        } else if (tag.name == "table") {
            // Never collect rows/cells from a nested clade table.
            val close = findMatchingClose(html, end + 1, tag.name)
            i = if (close < 0) end + 1 else close + 1
        } else {
            // Descend into tbody/thead/tr/div/... to reach the requested element.
            i = end + 1
        }
    }
    return out
}

private fun htmlCladeToWikitext(tableHtml: String): String? {
    val root = parseHtmlCladeTable(tableHtml) ?: return null
    val sb = StringBuilder("{{clade")
    appendCladeChildren(sb, root)
    sb.append("}}")
    return sb.toString()
}

private fun parseHtmlCladeTable(tableHtml: String): CladeNode.Branch? {
    val openEnd = tableHtml.indexOf('>')
    val closeStart = tableHtml.lastIndexOf("</table", ignoreCase = true)
    if (openEnd < 0 || closeStart < 0 || closeStart <= openEnd) return null
    val inner = tableHtml.substring(openEnd + 1, closeStart)
    val rows = directElements(inner, "tr")
    val children = ArrayList<CladeChild>()

    // Wikipedia writes the edge label on the same row as the leaf, but the sublabel is a
    // *separate* row below it (`<tr><td class="clade-slabel">65 Mya</td></tr>`), with the leaf
    // cell using rowspan. The old loop only read a sublabel from the leaf row, so every edge
    // label written that way disappeared. Remember the pending label/sublabel and attach it to
    // the child the previous row created.
    var pendingLabel = ""
    var pendingSublabel = ""

    fun attachPending(label: String, sublabel: String) {
        if (children.isEmpty()) return
        val last = children[children.lastIndex]
        val newLabel = last.label.ifBlank { label }
        val newSublabel = last.sublabel.ifBlank { sublabel }
        if (newLabel != last.label || newSublabel != last.sublabel) {
            children[children.lastIndex] = CladeChild(
                label = newLabel,
                sublabel = newSublabel,
                node = last.node,
                groupLabel = last.groupLabel,
                barColor = last.barColor
            )
        }
    }

    for (row in rows) {
        val cells = directElements(row.inner, "td") + directElements(row.inner, "th")
        var label = ""
        var sublabel = ""
        var leafHtml: String? = null
        for (cell in cells) {
            val classes = classTokens(cell.attributes)
            when {
                "clade-label" in classes -> label = plainText(cell.inner)
                "clade-slabel" in classes -> sublabel = plainText(cell.inner)
                "clade-leaf" in classes -> leafHtml = cell.inner
            }
        }
        val leaf = leafHtml
        if (leaf == null) {
            // Label/sublabel-only row. It belongs to the child created by the row above; if it
            // arrives before any leaf (some templates put the label first), keep it for the next.
            if (children.isNotEmpty() && (label.isNotBlank() || sublabel.isNotBlank())) {
                attachPending(label, sublabel)
            } else {
                if (label.isNotBlank()) pendingLabel = label
                if (sublabel.isNotBlank()) pendingSublabel = sublabel
            }
            continue
        }
        val effectiveLabel = label.ifBlank { pendingLabel }
        val effectiveSublabel = sublabel.ifBlank { pendingSublabel }
        pendingLabel = ""
        pendingSublabel = ""

        val nestedStart = findNextCladeTable(leaf, 0)
        val branch = if (nestedStart >= 0) {
            val nestedTagEnd = findTagEnd(leaf, nestedStart)
            val nestedClose =
                if (nestedTagEnd < 0) -1 else findMatchingClose(leaf, nestedTagEnd + 1, "table")
            if (nestedClose < 0) null
            else parseHtmlCladeTable(leaf.substring(nestedStart, nestedClose + 1))
        } else null
        val node: CladeNode = branch ?: CladeNode.Leaf(plainText(leaf))
        if (branch == null && (node as CladeNode.Leaf).text.isBlank()) continue
        children.add(CladeChild(effectiveLabel, effectiveSublabel, node))
    }
    return if (children.isEmpty()) null else CladeNode.Branch(children)
}

private fun appendCladeChildren(sb: StringBuilder, branch: CladeNode.Branch) {
    branch.children.forEachIndexed { index, child ->
        val n = index + 1
        if (child.label.isNotBlank()) {
            sb.append("|label").append(n).append('=').append(cladeText(child.label))
        }
        if (child.sublabel.isNotBlank()) {
            sb.append("|sublabel").append(n).append('=').append(cladeText(child.sublabel))
        }
        sb.append('|').append(n).append('=')
        when (val node = child.node) {
            is CladeNode.Leaf -> sb.append(cladeText(node.text))
            is CladeNode.Branch -> {
                sb.append("{{clade")
                appendCladeChildren(sb, node)
                sb.append("}}")
            }
        }
    }
}

/** Keeps the generated mini-template parseable: label text must not contain argument syntax. */
private fun cladeText(text: String): String = text
    .replace('|', '/')
    .replace('=', '-')
    .replace("{", "")
    .replace("}", "")
    .replace('\n', ' ')
    .trim()

/** Tag-free heading text (also decodes the small set of entities Wikipedia uses in headings). */
internal fun plainText(html: String): String {
    val withoutTags = html.replace(tagRegex, " ")
    return decodeEntities(withoutTags)
        .replace('\u00a0', ' ')
        .replace(Regex("\\s+"), " ")
        .trim()
}

private fun decodeEntities(text: String): String = entityRegex.replace(text) { match ->
    val entity = match.groupValues[1]
    when {
        entity.equals("amp", true) -> "&"
        entity.equals("lt", true) -> "<"
        entity.equals("gt", true) -> ">"
        entity.equals("quot", true) -> "\""
        entity.equals("apos", true) -> "'"
        entity.equals("nbsp", true) -> " "
        entity.equals("ndash", true) -> "\u2013"
        entity.equals("mdash", true) -> "\u2014"
        entity.startsWith("#x", true) ->
            entity.drop(2).toIntOrNull(16)
                ?.takeIf { Character.isValidCodePoint(it) }
                ?.let { String(Character.toChars(it)) } ?: match.value
        entity.startsWith("#") ->
            entity.drop(1).toIntOrNull()
                ?.takeIf { Character.isValidCodePoint(it) }
                ?.let { String(Character.toChars(it)) } ?: match.value
        else -> match.value
    }
}
