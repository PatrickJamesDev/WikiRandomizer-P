package org.nsh07.wikireader.ui.homeScreen

import androidx.compose.animation.ExperimentalSharedTransitionApi
import androidx.compose.animation.SharedTransitionScope
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CornerBasedShape
import androidx.compose.material3.MaterialTheme.colorScheme
import androidx.compose.material3.MaterialTheme.shapes
import androidx.compose.material3.MaterialTheme.typography
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation3.ui.LocalNavAnimatedContentScope
import org.nsh07.wikireader.parser.toWikitextAnnotatedStringSafe
import org.nsh07.wikireader.ui.image.FeedImage
import org.nsh07.wikireader.ui.image.ImagePrefetcher
import org.nsh07.wikireader.ui.theme.ColorConstants.colorMatrixInvert

@OptIn(ExperimentalSharedTransitionApi::class)
@Composable
fun SharedTransitionScope.ImageWithCaption(
    text: String,
    fontSize: Int,
    lang: String,
    darkTheme: Boolean,
    background: Boolean,
    checkFirstImage: Boolean,
    onLinkClick: (String) -> Unit,
    onLinkLongClick: (String) -> Unit = {},
    onClick: (String, String) -> Unit,
    modifier: Modifier = Modifier,
    pageImageUri: String? = null,
    showCaption: Boolean = true,
    shape: CornerBasedShape = shapes.large
) {
    val fileName = remember(text) {
        text.substringAfter(':').substringBefore('|').substringBefore("]]").trim()
    }
    val uriLow = remember(text) { ImagePrefetcher.fileUrl(lang, fileName) }
    val uriHigh = remember(text) {
        // 1920 px is a standard Wikimedia thumbnail step and is pre-cached by ImagePrefetcher,
        // so tapping a picture opens it instantly. The old code requested the un-cached original,
        // which always meant a fresh multi-megabyte download first.
        ImagePrefetcher.fileUrl(lang, fileName, width = 1920)
    }

    val pageImageName = remember(pageImageUri) { imageNameFromUrl(pageImageUri) }

    // `checkFirstImage` means "this section is under the lead image". The API leads with one
    // picture; when the article body shows the same file again we would draw it twice. The old
    // condition was inverted: with a lead image present it hid every intro picture whose file was
    // *different* (taking its caption with it) and rendered the duplicate instead. Skip only the
    // duplicate, and keep its caption below the lead image.
    val isLeadDuplicate = checkFirstImage && pageImageName != null &&
            pageImageName.equals(fileName.replace(' ', '_'), ignoreCase = true)

    val description = remember(text) {
        // The caption is everything after the file name, not just the first parameter:
        // captions routinely contain links and templates with their own `|`.
        text.substringAfter('|', "")
            .substringBeforeLast("]]")
            .substringBeforeLast("|invert")
            .trim()
    }
    val invert = remember(text) { text.contains("|invert") }
    val captionColorScheme = colorScheme
    val captionTypography = typography

    if (!isLeadDuplicate) {
        FeedImage(
            source = uriLow,
            description = description,
            loadingIndicator = false,
            lightPlaceholder = true,
            colorFilter = if (invert && darkTheme && !background) // Invert colors in dark theme
                ColorFilter.colorMatrix(ColorMatrix(colorMatrixInvert))
            else null,
            background = background,
            modifier = modifier
                .sharedBounds(
                    sharedContentState = rememberSharedContentState(uriHigh),
                    animatedVisibilityScope = LocalNavAnimatedContentScope.current
                )
                .padding(horizontal = 16.dp)
                .padding(top = 8.dp)
                .clip(shape)
                .widthIn(max = 512.dp)
                .clickable(onClick = { onClick(uriHigh, description) })
        )
    }
    if (showCaption && description.isNotBlank()) {
        val caption = remember(description, fontSize, captionColorScheme, captionTypography) {
            description.toWikitextAnnotatedStringSafe(
                colorScheme = captionColorScheme,
                fontSize = fontSize - 2,
                loadPage = onLinkClick,
                typography = captionTypography,
                showRef = {}
            )
        }
        val captionDisplay = remember(caption, captionColorScheme.primary) {
            caption.toTappableArticleLinks(captionColorScheme.primary)
        }
        val captionLayout = remember(captionDisplay) {
            androidx.compose.runtime.mutableStateOf<androidx.compose.ui.text.TextLayoutResult?>(null)
        }
        Text(
            text = captionDisplay,
            fontSize = (fontSize - 2).sp,
            lineHeight = (24 * ((fontSize - 2) / 16.0)).toInt().sp,
            textAlign = TextAlign.Center,
            color = colorScheme.onSurfaceVariant,
            onTextLayout = { captionLayout.value = it },
            modifier = Modifier
                .sharedBounds(
                    sharedContentState = rememberSharedContentState(description),
                    animatedVisibilityScope = LocalNavAnimatedContentScope.current
                )
                .padding(horizontal = 16.dp)
                // The caption of a picture that is already shown as the lead image sits directly
                // under it; a normal picture caption sits under its own picture.
                .padding(top = if (isLeadDuplicate) 4.dp else 8.dp, bottom = 12.dp)
                .articleLinkGestures(
                    text = captionDisplay,
                    layoutProvider = { captionLayout.value },
                    onLinkClick = onLinkClick,
                    onLinkLongClick = onLinkLongClick
                )
        )
    }
}

/** File name of the last path segment of an image URL ("960px-Pea.jpg" -> "Pea.jpg"). */
internal fun imageNameFromUrl(url: String?): String? {
    if (url.isNullOrBlank()) return null
    val segment = url.substringBefore('?').substringAfterLast('/')
    if (segment.isBlank()) return null
    val decoded = runCatching { java.net.URLDecoder.decode(segment, "UTF-8") }.getOrDefault(segment)
    return decoded.replace(Regex("^\\d+px-"), "").replace(' ', '_')
}