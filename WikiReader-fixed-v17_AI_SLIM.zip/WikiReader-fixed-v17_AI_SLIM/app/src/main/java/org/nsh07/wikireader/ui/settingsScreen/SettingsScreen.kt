package org.nsh07.wikireader.ui.settingsScreen

import kotlin.math.roundToInt
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.runtime.saveable.rememberSaveable
import android.app.LocaleManager
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ButtonGroupDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialShapes
import androidx.compose.material3.MaterialTheme.colorScheme
import androidx.compose.material3.MaterialTheme.motionScheme
import androidx.compose.material3.MaterialTheme.typography
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.ToggleButton
import androidx.compose.material3.ToggleButtonDefaults
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.toShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.launch
import org.nsh07.wikireader.R
import org.nsh07.wikireader.R.string
import org.nsh07.wikireader.data.LibraryStats
import org.nsh07.wikireader.data.langCodeToName
import org.nsh07.wikireader.data.toColor
import org.nsh07.wikireader.ui.homeScreen.viewModel.HomeAction
import org.nsh07.wikireader.ui.homeScreen.viewModel.HomeSubscreen
import org.nsh07.wikireader.ui.settingsScreen.viewModel.PreferencesState
import org.nsh07.wikireader.ui.settingsScreen.viewModel.SettingsAction
import org.nsh07.wikireader.ui.settingsScreen.viewModel.SettingsViewModel
import org.nsh07.wikireader.ui.theme.CustomColors.listItemColors
import org.nsh07.wikireader.ui.theme.CustomColors.topBarColors
import org.nsh07.wikireader.ui.theme.WRShapeDefaults.bottomListItemShape
import org.nsh07.wikireader.ui.theme.WRShapeDefaults.cardShape
import org.nsh07.wikireader.ui.theme.WRShapeDefaults.middleListItemShape
import org.nsh07.wikireader.ui.theme.WRShapeDefaults.topListItemShape
import org.nsh07.wikireader.ui.theme.WikiRandomizerPTheme
import kotlin.math.round

/** One row in the Settings search results. [checked] makes it a switch, [value] shows a value. */
private data class SettingsSearchEntry(
    val title: String,
    val description: String,
    val keywords: String = "",
    val icon: Int,
    val value: String? = null,
    val checked: Boolean? = null,
    val action: () -> Unit
)

@Composable
fun SettingsScreenRoot(
    preferencesState: PreferencesState,
    lastBackStackEntry: HomeSubscreen,
    recentLangs: List<String>,
    languageSearchStr: String,
    languageSearchQuery: String,
    onHomeAction: (HomeAction) -> Unit,
    /** Opens the Reading & topics submenu that contains the random-topic picker. */
    onNavigateToReadingSettings: () -> Unit = {},
    onReplayTutorial: () -> Unit = {},
    onGetLibraryStats: suspend () -> LibraryStats = {
        LibraryStats(totalArticles = 0, unseen = 0, topics = emptyList())
    },
    onSetTopicEnabled: suspend (String, Boolean) -> Unit = { _, _ -> },
    onBack: () -> Unit,
    modifier: Modifier = Modifier,
    viewModel: SettingsViewModel = viewModel(factory = SettingsViewModel.Factory)
) {
    val context = LocalContext.current

    val themeMap: Map<String, Pair<Int, String>> = remember {
        mapOf(
            "auto" to Pair(
                R.drawable.brightness_auto,
                context.getString(string.themeSystemDefault)
            ),
            "light" to Pair(R.drawable.light_mode, context.getString(string.themeLight)),
            "dark" to Pair(R.drawable.dark_mode, context.getString(string.themeDark))
        )
    }
    val reverseThemeMap: Map<String, String> = remember {
        mapOf(
            context.getString(string.themeSystemDefault) to "auto",
            context.getString(string.themeLight) to "light",
            context.getString(string.themeDark) to "dark"
        )
    }
    val fontStyleMap: Map<String, String> = remember {
        mapOf(
            "sans" to context.getString(string.fontStyleSansSerif),
            "serif" to context.getString(string.fontStyleSerif)
        )
    }
    val reverseFontStyleMap: Map<String, String> = remember {
        mapOf(
            context.getString(string.fontStyleSansSerif) to "sans",
            context.getString(string.fontStyleSerif) to "serif"
        )
    }
    val fontStyles = remember {
        listOf(
            context.getString(string.fontStyleSansSerif),
            context.getString(string.fontStyleSerif)
        )
    }

    SettingsScreen(
        preferencesState = preferencesState,
        lastBackStackEntry = lastBackStackEntry,
        recentLangs = recentLangs,
        languageSearchStr = languageSearchStr,
        languageSearchQuery = languageSearchQuery,
        themeMap = themeMap,
        reverseThemeMap = reverseThemeMap,
        fontStyles = fontStyles,
        fontStyleMap = fontStyleMap,
        reverseFontStyleMap = reverseFontStyleMap,
        onAction = viewModel::onAction,
        onHomeAction = onHomeAction,
        onNavigateToReadingSettings = onNavigateToReadingSettings,
        onReplayTutorial = onReplayTutorial,
        onGetLibraryStats = onGetLibraryStats,
        onSetTopicEnabled = onSetTopicEnabled,
        onBack = onBack,
        modifier = modifier
    )
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun SettingsScreen(
    preferencesState: PreferencesState,
    lastBackStackEntry: HomeSubscreen,
    recentLangs: List<String>,
    languageSearchStr: String,
    languageSearchQuery: String,
    themeMap: Map<String, Pair<Int, String>>,
    reverseThemeMap: Map<String, String>,
    fontStyles: List<String>,
    fontStyleMap: Map<String, String>,
    reverseFontStyleMap: Map<String, String>,
    onAction: (SettingsAction) -> Unit,
    onHomeAction: (HomeAction) -> Unit,
    onNavigateToReadingSettings: () -> Unit = {},
    onReplayTutorial: () -> Unit = {},
    onGetLibraryStats: suspend () -> LibraryStats = {
        LibraryStats(totalArticles = 0, unseen = 0, topics = emptyList())
    },
    onSetTopicEnabled: suspend (String, Boolean) -> Unit = { _, _ -> },
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val uriHandler = LocalUriHandler.current
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val coroutineScope = rememberCoroutineScope()

    val appInfoIntent = remember {
        Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
            data = Uri.fromParts("package", context.packageName, null)
        }
    }

    val currentLocales =
        if (Build.VERSION.SDK_INT >= 33) {
            context
                .getSystemService(LocaleManager::class.java)
                .applicationLocales
        } else null
    val currentLocalesSize = currentLocales?.size() ?: 0

    val theme = preferencesState.theme
    val fontStyle = preferencesState.fontStyle
    val color = preferencesState.colorScheme.toColor()

    val scrollBehavior = TopAppBarDefaults.exitUntilCollapsedScrollBehavior()
    val snackBarHostState = remember { SnackbarHostState() }

    val (showThemeDialog, setShowThemeDialog) = remember { mutableStateOf(false) }
    val (showDebugLog, setShowDebugLog) = remember { mutableStateOf(false) }
    val (showBugReport, setShowBugReport) = remember { mutableStateOf(false) }
    val (showResetSettingsDialog, setShowResetSettingsDialog) = remember { mutableStateOf(false) }
    val (showColorSchemeDialog, setShowColorSchemeDialog) = remember { mutableStateOf(false) }
    val (showLanguageSheet, setShowLanguageSheet) = remember { mutableStateOf(false) }
    val (showAppLocaleSheet, setShowAppLocaleSheet) = remember { mutableStateOf(false) }
    var settingsSearchQuery by rememberSaveable { mutableStateOf("") }

    var libraryStats by remember { mutableStateOf<LibraryStats?>(null) }
    LaunchedEffect(preferencesState.lang) {
        libraryStats = onGetLibraryStats()
    }
    // Settings stays composed while the user builds/removes a topic on the Random topics screen.
    // Refresh on return so the switch list never shows a stale library.
    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        coroutineScope.launch { libraryStats = onGetLibraryStats() }
    }

    var animateFontSize by remember { mutableStateOf(true) }
    var fontSizeFloat by remember(preferencesState.fontSize) { mutableFloatStateOf(preferencesState.fontSize.toFloat()) }
    val fontSizeAnimated by animateFloatAsState(
        fontSizeFloat,
        animationSpec = if (animateFontSize) motionScheme.defaultSpatialSpec()
        else tween(durationMillis = 0)
    )

    val disabledAlpha = 0.5f

    val disabledListColors =
        ListItemDefaults.colors(
            containerColor = colorScheme.surfaceContainerLow,
            headlineColor = listItemColors.headlineColor.copy(disabledAlpha),
            leadingIconColor = listItemColors.leadingIconColor.copy(disabledAlpha),
            overlineColor = listItemColors.overlineColor.copy(disabledAlpha),
            supportingColor = listItemColors.supportingTextColor.copy(disabledAlpha),
            trailingIconColor = listItemColors.trailingIconColor.copy(disabledAlpha),
        )

    // Compose Material 3 uses the 3P spec, which hasn't yet been updated with the new
    // switch tokens, which are already used across Google products.
    // Therefore we must override certain colors to let the Switch remain accessible
    // with the new 2025 color spec.
    // See https://github.com/nsh07/WikiReader/issues/272 for more info
    //
    // Once Compose Material 3 updates Switch tokens, this should be removed.
    val switchColors = SwitchDefaults.colors(
        checkedIconColor = colorScheme.primary,
    )

    val switchItems = remember(preferencesState) {
        listOf(
            SettingsSwitchItem(
                preferencesState.blackTheme,
                R.drawable.contrast,
                string.settingBlackTheme,
                string.settingBlackThemeDesc,
                SettingsAction::SaveBlackTheme
            ),
            SettingsSwitchItem(
                preferencesState.dataSaver,
                R.drawable.data_saver_on,
                string.settingDataSaver,
                string.settingDataSaverDesc,
                SettingsAction::SaveDataSaver
            ),
            SettingsSwitchItem(
                preferencesState.feedEnabled,
                R.drawable.feed,
                string.settingFeed,
                string.settingFeedDesc,
                SettingsAction::SaveFeedEnabled,
                enabled = !preferencesState.dataSaver
            ),
            SettingsSwitchItem(
                preferencesState.expandedSections,
                R.drawable.expand_all,
                string.settingExpandSections,
                string.settingExpandSectionsDesc,
                SettingsAction::SaveExpandedSections
            ),
            SettingsSwitchItem(
                preferencesState.imageBackground,
                R.drawable.texture,
                string.settingImageBackground,
                string.settingImageBackgroundDesc,
                SettingsAction::SaveImageBackground
            ),
            SettingsSwitchItem(
                preferencesState.immersiveMode,
                R.drawable.open_in_full,
                string.settingImmersiveMode,
                string.settingImmersiveModeDesc,
                SettingsAction::SaveImmersiveMode
            ),
            SettingsSwitchItem(
                preferencesState.renderMath,
                R.drawable.function,
                string.settingRenderMath,
                string.settingRenderMathDesc,
                SettingsAction::SaveRenderMath
            ),
            SettingsSwitchItem(
                preferencesState.saveOffline,
                R.drawable.download,
                string.settingSaveOffline,
                string.settingSaveOfflineDesc,
                SettingsAction::SaveSaveOffline
            ),
            SettingsSwitchItem(
                preferencesState.browsingHistory,
                R.drawable.manage_history,
                string.history,
                string.historyDesc,
                SettingsAction::SaveHistory
            ),
            SettingsSwitchItem(
                preferencesState.searchHistory,
                R.drawable.search_history,
                string.settingSearchHistory,
                string.settingSearchHistoryDesc,
                SettingsAction::SaveSearchHistory
            ),
            SettingsSwitchItem(
                preferencesState.pullForRandom,
                R.drawable.keyboard_arrow_down,
                string.settingPullForRandom,
                string.settingPullForRandomDesc,
                SettingsAction::SavePullForRandom
            ),
            SettingsSwitchItem(
                preferencesState.preloadArticles,
                R.drawable.shuffle,
                string.settingPreloadArticles,
                string.settingPreloadArticlesDesc,
                SettingsAction::SavePreloadArticles,
                enabled = !preferencesState.dataSaver
            ),
            SettingsSwitchItem(
                preferencesState.personalizationEnabled,
                R.drawable.thumb_up,
                string.settingPersonalization,
                string.settingPersonalizationDesc,
                SettingsAction::SavePersonalization
            ),
            SettingsSwitchItem(
                preferencesState.reduceMotion,
                R.drawable.update,
                string.settingReduceMotion,
                string.settingReduceMotionDesc,
                SettingsAction::SaveReduceMotion
            ),
            SettingsSwitchItem(
                preferencesState.hapticFeedback,
                R.drawable.open_in_full,
                string.settingHaptics,
                string.settingHapticsDesc,
                SettingsAction::SaveHapticFeedback
            ),
            SettingsSwitchItem(
                preferencesState.boldArticleText,
                R.drawable.format_size,
                string.settingBoldText,
                string.settingBoldTextDesc,
                SettingsAction::SaveBoldArticleText
            ),
            SettingsSwitchItem(
                preferencesState.donationPrompts,
                R.drawable.heart,
                string.settingDonationPrompts,
                string.settingDonationPromptsDesc,
                SettingsAction::SaveDonationPrompts
            ),
            SettingsSwitchItem(
                preferencesState.supporterMode,
                R.drawable.heart,
                string.settingSupporterMode,
                string.settingSupporterModeDesc,
                SettingsAction::SaveSupporterMode
            )
        )
    }

    if (showThemeDialog)
        ThemeDialog(
            themeMap = themeMap,
            reverseThemeMap = reverseThemeMap,
            theme = theme,
            setShowThemeDialog = setShowThemeDialog,
            setTheme = { onAction(SettingsAction.SaveTheme(it)) }
        )
    if (showColorSchemeDialog)
        ColorSchemePickerDialog(
            currentColor = color,
            onColorChange = { onAction(SettingsAction.SaveColorScheme(it.toString())) },
            setShowDialog = setShowColorSchemeDialog
        )
    if (showDebugLog) DebugLogDialog(onDismiss = { setShowDebugLog(false) })
    if (showBugReport) BugReportDialog(
        onDismiss = { setShowBugReport(false) },
        onCopied = {
            setShowBugReport(false)
            coroutineScope.launch {
                snackBarHostState.showSnackbar(context.getString(R.string.reportBugCopied))
            }
        }
    )
    if (showResetSettingsDialog)
        ResetSettingsDialog(
            onResetSettings = { onAction(SettingsAction.ResetSettings) },
            setShowResetSettingsDialog = setShowResetSettingsDialog,
            showSnackbar = { coroutineScope.launch { snackBarHostState.showSnackbar(it) } }
        )
    if (showLanguageSheet)
        LanguageBottomSheet(
            lang = preferencesState.lang,
            recentLangs = recentLangs,
            searchStr = languageSearchStr,
            searchQuery = languageSearchQuery,
            setShowSheet = setShowLanguageSheet,
            setLang = {
                // The Home view model observes the language preference and resets to a feed in
                // the new language. Reloading the current article here would ask the new wiki
                // for an article that may not exist (e.g. an English-only title), showing an
                // error page instead of the new-language feed.
                onAction(SettingsAction.SaveLang(it))
            },
            setSearchStr = { onHomeAction(HomeAction.UpdateLanguageSearchStr(it)) }
        )
    if (showAppLocaleSheet && currentLocales != null)
        AppLocaleBottomSheet(
            searchStr = languageSearchStr,
            currentLocales = currentLocales,
            setSearchStr = { onHomeAction(HomeAction.UpdateLanguageSearchStr(it)) },
            setShowSheet = setShowAppLocaleSheet
        )

    Scaffold(
        topBar = {
            SettingsTopBar(
                scrollBehavior = scrollBehavior,
                onBack = onBack
            )
        },
        snackbarHost = { SnackbarHost(snackBarHostState) },
        modifier = modifier
            .fillMaxSize()
            .nestedScroll(scrollBehavior.nestedScrollConnection)
    ) { insets ->
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(2.dp),
            contentPadding = insets,
            modifier = Modifier
                .background(topBarColors.containerColor)
                .padding(horizontal = 16.dp)
        ) {
            item { Spacer(Modifier.height(8.dp)) }
            item(key = "settings-search") {
                OutlinedTextField(
                    value = settingsSearchQuery,
                    onValueChange = { settingsSearchQuery = it },
                    placeholder = { Text(stringResource(string.searchSettings)) },
                    leadingIcon = {
                        Icon(painterResource(R.drawable.search), contentDescription = null)
                    },
                    trailingIcon = {
                        if (settingsSearchQuery.isNotEmpty()) {
                            IconButton(onClick = { settingsSearchQuery = "" }) {
                                Icon(
                                    painterResource(R.drawable.clear),
                                    contentDescription = stringResource(string.clearSearchField)
                                )
                            }
                        }
                    },
                    singleLine = true,
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp, bottom = 8.dp)
                )
            }
            if (settingsSearchQuery.isBlank()) {
            item {
                ClickableListItem(
                    leadingContent = {
                        Icon(
                            painterResource(R.drawable.view_list),
                            tint = colorScheme.primary,
                            contentDescription = null
                        )
                    },
                    headlineContent = { Text(stringResource(string.settingsReadingTopics)) },
                    supportingContent = {
                        val stats = libraryStats
                        Text(
                            if (stats == null || stats.topics.isEmpty())
                                stringResource(string.settingsReadingTopicsDesc)
                            else
                                stringResource(
                                    string.settingsLibrarySummary,
                                    stats.totalArticles,
                                    stats.topics.size
                                )
                        )
                    },
                    colors = listItemColors,
                    items = 1,
                    index = 0
                ) { onNavigateToReadingSettings() }
            }
            item {
                ClickableListItem(
                    leadingContent = {
                        Icon(
                            painterResource(R.drawable.palette),
                            tint = colorScheme.primary,
                            contentDescription = null
                        )
                    },
                    headlineContent = { Text(stringResource(string.settingColorScheme)) },
                    supportingContent = {
                        if (color == Color.White) Text(stringResource(string.colorSchemeDynamic))
                        else Text(stringResource(string.colorSchemeColor))
                    },
                    colors = listItemColors,
                    items = 3,
                    index = 0
                ) { setShowColorSchemeDialog(true) }
            }
            item {
                ClickableListItem(
                    leadingContent = {
                        Icon(
                            painterResource(themeMap[theme]!!.first),
                            contentDescription = null
                        )
                    },
                    headlineContent = { Text(stringResource(string.settingTheme)) },
                    supportingContent = { Text(themeMap[theme]!!.second) },
                    colors = listItemColors,
                    items = 3,
                    index = 1
                ) { setShowThemeDialog(true) }
            }
            item {
                ListItem(
                    leadingContent = {
                        Icon(painterResource(switchItems[0].icon), contentDescription = null)
                    },
                    headlineContent = { Text(stringResource(switchItems[0].label)) },
                    supportingContent = { Text(stringResource(switchItems[0].description)) },
                    trailingContent = {
                        Switch(
                            checked = switchItems[0].checked,
                            onCheckedChange = { onAction(switchItems[0].actionConstructor(it)) },
                            thumbContent = {
                                if (switchItems[0].checked) {
                                    Icon(
                                        painter = painterResource(R.drawable.check),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                } else {
                                    Icon(
                                        painter = painterResource(R.drawable.clear),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                }
                            },
                            enabled = switchItems[0].enabled,
                            colors = switchColors
                        )
                    },
                    colors = listItemColors,
                    modifier = Modifier
                        .clip(bottomListItemShape)
                )
            }
            item { Spacer(Modifier.height(12.dp)) }
            item {
                ClickableListItem(
                    leadingContent = {
                        Icon(
                            painterResource(R.drawable.translate),
                            contentDescription = null
                        )
                    },
                    headlineContent = { Text(stringResource(string.settingWikipediaLanguage)) },
                    supportingContent = { Text(langCodeToName(preferencesState.lang)) },
                    colors = listItemColors,
                    items = 4,
                    index = 0
                ) { setShowLanguageSheet(true) }
            }
            if (currentLocales != null)
                item {
                    ClickableListItem(
                        leadingContent = {
                            Icon(
                                painterResource(R.drawable.language),
                                contentDescription = null
                            )
                        },
                        headlineContent = { Text(stringResource(string.settingAppLanguage)) },
                        supportingContent = {
                            Text(
                                if (currentLocalesSize > 0) currentLocales.get(0).displayName
                                else stringResource(string.themeSystemDefault)
                            )
                        },
                        colors = listItemColors,
                        items = 4,
                        index = 1
                    ) { setShowAppLocaleSheet(true) }
                }
            item {
                ListItem(
                    leadingContent = {
                        Icon(
                            painterResource(R.drawable.serif),
                            contentDescription = null
                        )
                    },
                    headlineContent = { Text(stringResource(string.settingFontStyle)) },
                    supportingContent = {
                        Row(
                            horizontalArrangement =
                                Arrangement.spacedBy(ButtonGroupDefaults.ConnectedSpaceBetween),
                            modifier = Modifier.padding(vertical = 4.dp)
                        ) {
                            fontStyles.forEachIndexed { index, label ->
                                ToggleButton(
                                    checked = label == fontStyleMap[fontStyle],
                                    onCheckedChange = {
                                        onAction(
                                            SettingsAction.SaveFontStyle(
                                                reverseFontStyleMap[label] ?: "sans"
                                            )
                                        )
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .padding(top = 4.dp)
                                        .height(40.dp),
                                    shapes =
                                        when (index) {
                                            0 -> ButtonGroupDefaults.connectedLeadingButtonShapes()
                                            fontStyles.lastIndex -> ButtonGroupDefaults.connectedTrailingButtonShapes()
                                            else -> ButtonGroupDefaults.connectedMiddleButtonShapes()
                                        }
                                ) {
                                    AnimatedVisibility(
                                        label == fontStyleMap[fontStyle],
                                        enter = scaleIn(motionScheme.fastSpatialSpec()) +
                                                expandHorizontally(motionScheme.fastSpatialSpec()) +
                                                fadeIn(),
                                        exit = scaleOut(motionScheme.fastSpatialSpec()) +
                                                shrinkHorizontally(motionScheme.fastSpatialSpec()) +
                                                fadeOut()
                                    ) {
                                        Icon(
                                            painterResource(R.drawable.check),
                                            contentDescription = null
                                        )
                                    }
                                    Spacer(Modifier.size(ToggleButtonDefaults.IconSpacing))
                                    Text(label)
                                }
                            }
                        }
                    },
                    colors = listItemColors,
                    modifier = Modifier
                        .clip(middleListItemShape)
                )
            }
            item {
                ListItem(
                    leadingContent = {
                        Icon(
                            painterResource(R.drawable.format_size),
                            contentDescription = null
                        )
                    },
                    headlineContent = { Text(stringResource(string.settingFontSize)) },
                    supportingContent = {
                        Column {
                            val intSize = round(fontSizeFloat).toInt()
                            Text(intSize.toString())
                            Slider(
                                value = fontSizeAnimated,
                                onValueChange = {
                                    animateFontSize = false
                                    if (round(it).toInt() != intSize)
                                        haptic.performHapticFeedback(HapticFeedbackType.SegmentTick)
                                    fontSizeFloat = it
                                },
                                valueRange = 10f..22f,
                                onValueChangeFinished = {
                                    animateFontSize = true
                                    onAction(SettingsAction.SaveFontSize(round(fontSizeFloat).toInt()))
                                    fontSizeFloat = round(fontSizeFloat)
                                }
                            )
                        }
                    },
                    colors = listItemColors,
                    modifier = Modifier
                        .clip(bottomListItemShape)
                )
            }
            item {
                // Renderer: fast native wikitext parsing, or Wikipedia's fully rendered HTML.
                ListItem(
                    leadingContent = {
                        Icon(painterResource(R.drawable.code), contentDescription = null)
                    },
                    headlineContent = { Text(stringResource(string.settingArticleFormat)) },
                    supportingContent = {
                        Column {
                            Text(stringResource(string.settingArticleFormatDesc))
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(
                                    ButtonGroupDefaults.ConnectedSpaceBetween
                                ),
                                modifier = Modifier.padding(top = 8.dp)
                            ) {
                                val html = preferencesState.renderMode == "html"
                                ToggleButton(
                                    checked = !html,
                                    onCheckedChange = {
                                        onAction(SettingsAction.SaveRenderMode("wikitext"))
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(40.dp),
                                    shapes = ButtonGroupDefaults.connectedLeadingButtonShapes()
                                ) {
                                    Text(stringResource(string.articleFormatWikitext))
                                }
                                ToggleButton(
                                    checked = html,
                                    onCheckedChange = {
                                        onAction(SettingsAction.SaveRenderMode("html"))
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(40.dp),
                                    shapes = ButtonGroupDefaults.connectedTrailingButtonShapes()
                                ) {
                                    Text(stringResource(string.articleFormatHtml))
                                }
                            }
                        }
                    },
                    colors = listItemColors,
                    modifier = Modifier.clip(topListItemShape)
                )
            }
            item {
                // Physical side of the navigation drawer / edge-swipe gesture.
                ListItem(
                    leadingContent = {
                        Icon(painterResource(R.drawable.menu), contentDescription = null)
                    },
                    headlineContent = { Text(stringResource(string.settingMenuSide)) },
                    supportingContent = {
                        Column {
                            Text(stringResource(string.settingMenuSideDesc))
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(
                                    ButtonGroupDefaults.ConnectedSpaceBetween
                                ),
                                modifier = Modifier.padding(top = 8.dp)
                            ) {
                                val right = preferencesState.menuSide == "right"
                                ToggleButton(
                                    checked = !right,
                                    onCheckedChange = {
                                        onAction(SettingsAction.SaveMenuSide("left"))
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(40.dp),
                                    shapes = ButtonGroupDefaults.connectedLeadingButtonShapes()
                                ) {
                                    Text(stringResource(string.menuSideLeft))
                                }
                                ToggleButton(
                                    checked = right,
                                    onCheckedChange = {
                                        onAction(SettingsAction.SaveMenuSide("right"))
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .height(40.dp),
                                    shapes = ButtonGroupDefaults.connectedTrailingButtonShapes()
                                ) {
                                    Text(stringResource(string.menuSideRight))
                                }
                            }
                        }
                    },
                    colors = listItemColors,
                    modifier = Modifier.clip(bottomListItemShape)
                )
            }
            item { Spacer(Modifier.height(12.dp)) }
            item {
                // How closely articles must match the topic (hides low-relevance articles).
                var strictPos by remember(preferencesState.topicStrictness) {
                    mutableFloatStateOf(preferencesState.topicStrictness.toFloat())
                }
                ListItem(
                    leadingContent = {
                        Icon(painterResource(R.drawable.check), contentDescription = null)
                    },
                    headlineContent = { Text(stringResource(string.settingStrictness)) },
                    supportingContent = {
                        Column {
                            Text(stringResource(string.settingStrictnessDesc))
                            Text(
                                stringResource(
                                    when (strictPos.roundToInt()) {
                                        0 -> string.strictnessBroad
                                        2 -> string.strictnessStrict
                                        3 -> string.strictnessVeryStrict
                                        else -> string.strictnessBalanced
                                    }
                                ),
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Slider(
                                value = strictPos,
                                onValueChange = { strictPos = it.roundToInt().toFloat() },
                                onValueChangeFinished = {
                                    onAction(SettingsAction.SaveTopicStrictness(strictPos.roundToInt()))
                                },
                                valueRange = 0f..3f,
                                steps = 2
                            )
                        }
                    },
                    colors = listItemColors,
                    modifier = Modifier.clip(middleListItemShape)
                )
            }
            item {
                // Popularity preference (replaces the old "popular articles only" switch).
                var sliderPos by remember(preferencesState.popularityBias) {
                    mutableFloatStateOf(preferencesState.popularityBias.toFloat())
                }
                ListItem(
                    leadingContent = {
                        Icon(painterResource(R.drawable.upward), contentDescription = null)
                    },
                    headlineContent = { Text(stringResource(string.settingPopularity)) },
                    supportingContent = {
                        Column {
                            Text(stringResource(string.settingPopularityDesc))
                            Text(
                                stringResource(
                                    when (sliderPos.roundToInt()) {
                                        -2 -> string.popularityObscureOnly
                                        -1 -> string.popularityPreferObscure
                                        1 -> string.popularityPreferPopular
                                        2 -> string.popularityPopularOnly
                                        else -> string.popularityNoPreference
                                    }
                                ),
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Slider(
                                value = sliderPos,
                                onValueChange = { sliderPos = it.roundToInt().toFloat() },
                                onValueChangeFinished = {
                                    onAction(SettingsAction.SavePopularityBias(sliderPos.roundToInt()))
                                },
                                valueRange = -2f..2f,
                                steps = 3
                            )
                        }
                    },
                    colors = listItemColors,
                    modifier = Modifier.clip(middleListItemShape)
                )
            }
            item {
                ListItem(
                    leadingContent = {
                        Icon(painterResource(R.drawable.expand_all), contentDescription = null)
                    },
                    headlineContent = { Text(stringResource(string.settingAvoidStubs)) },
                    supportingContent = { Text(stringResource(string.settingAvoidStubsDesc)) },
                    trailingContent = {
                        Switch(
                            checked = preferencesState.avoidStubs,
                            onCheckedChange = { onAction(SettingsAction.SaveAvoidStubs(it)) },
                            thumbContent = {
                                if (preferencesState.avoidStubs) {
                                    Icon(
                                        painter = painterResource(R.drawable.check),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                } else {
                                    Icon(
                                        painter = painterResource(R.drawable.clear),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                }
                            },
                            colors = switchColors
                        )
                    },
                    colors = listItemColors,
                    modifier = Modifier.clip(middleListItemShape)
                )
            }
            item {
                ListItem(
                    leadingContent = {
                        Icon(painterResource(R.drawable.check), contentDescription = null)
                    },
                    headlineContent = { Text(stringResource(string.settingPreferQuality)) },
                    supportingContent = { Text(stringResource(string.settingPreferQualityDesc)) },
                    trailingContent = {
                        Switch(
                            checked = preferencesState.preferQuality,
                            onCheckedChange = { onAction(SettingsAction.SavePreferQuality(it)) },
                            thumbContent = {
                                Icon(
                                    painter = painterResource(
                                        if (preferencesState.preferQuality) R.drawable.check else R.drawable.clear
                                    ),
                                    contentDescription = null,
                                    modifier = Modifier.size(SwitchDefaults.IconSize),
                                )
                            },
                            colors = switchColors
                        )
                    },
                    colors = listItemColors,
                    modifier = Modifier.clip(middleListItemShape)
                )
            }
            item {
                ListItem(
                    leadingContent = {
                        Icon(painterResource(R.drawable.image), contentDescription = null)
                    },
                    headlineContent = { Text(stringResource(string.settingImagesOnly)) },
                    supportingContent = { Text(stringResource(string.settingImagesOnlyDesc)) },
                    trailingContent = {
                        Switch(
                            checked = preferencesState.onlyArticlesWithImages,
                            onCheckedChange = { onAction(SettingsAction.SaveOnlyArticlesWithImages(it)) },
                            thumbContent = {
                                if (preferencesState.onlyArticlesWithImages) {
                                    Icon(
                                        painter = painterResource(R.drawable.check),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                } else {
                                    Icon(
                                        painter = painterResource(R.drawable.clear),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                }
                            },
                            colors = switchColors
                        )
                    },
                    colors = listItemColors,
                    modifier = Modifier.clip(bottomListItemShape)
                )
            }
            item { Spacer(Modifier.height(12.dp)) }
            itemsIndexed(switchItems.drop(1)) { index, item ->
                ListItem(
                    leadingContent = {
                        Icon(painterResource(item.icon), contentDescription = null)
                    },
                    headlineContent = { Text(stringResource(item.label)) },
                    supportingContent = { Text(stringResource(item.description)) },
                    trailingContent = {
                        Switch(
                            checked = item.checked && item.enabled,
                            onCheckedChange = { onAction(item.actionConstructor(it)) },
                            thumbContent = {
                                if (item.checked && item.enabled) {
                                    Icon(
                                        painter = painterResource(R.drawable.check),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                } else {
                                    Icon(
                                        painter = painterResource(R.drawable.clear),
                                        contentDescription = null,
                                        modifier = Modifier.size(SwitchDefaults.IconSize),
                                    )
                                }
                            },
                            enabled = item.enabled,
                            colors = switchColors
                        )
                    },
                    colors =
                        if (item.enabled)
                            listItemColors
                        else
                            disabledListColors,
                    modifier = Modifier
                        .clip(
                            when (index) {
                                0 -> topListItemShape
                                switchItems.lastIndex - 1 -> bottomListItemShape
                                else -> middleListItemShape
                            }
                        )
                )
            }
            item { Spacer(Modifier.height(12.dp)) }
            item {
                ClickableListItem(
                    leadingContent = {
                        Icon(
                            painterResource(R.drawable.outline_info),
                            tint = colorScheme.primary,
                            contentDescription = null
                        )
                    },
                    headlineContent = { Text(stringResource(string.settingReplayTutorial)) },
                    supportingContent = { Text(stringResource(string.settingReplayTutorialDesc)) },
                    colors = listItemColors,
                    items = 1,
                    index = 0
                ) { onReplayTutorial() }
            }
            item { Spacer(Modifier.height(12.dp)) }
            item {
                ListItem(
                    leadingContent = {
                        Icon(painterResource(R.drawable.search_history), contentDescription = null)
                    },
                    headlineContent = { Text(stringResource(string.settingDebugLogging)) },
                    supportingContent = { Text(stringResource(string.settingDebugLoggingDesc)) },
                    trailingContent = {
                        Switch(
                            checked = preferencesState.debugLogging,
                            onCheckedChange = { onAction(SettingsAction.SaveDebugLogging(it)) },
                            colors = switchColors
                        )
                    },
                    colors = listItemColors,
                    modifier = Modifier.clip(topListItemShape)
                )
            }
            item {
                ListItem(
                    leadingContent = {
                        Icon(painterResource(R.drawable.expand_all), contentDescription = null)
                    },
                    headlineContent = { Text(stringResource(string.settingViewDebugLog)) },
                    modifier = Modifier
                        .clip(bottomListItemShape)
                        .clickable { setShowDebugLog(true) },
                    colors = listItemColors
                )
            }
            if (preferencesState.supporterMode) {
                item {
                    ListItem(
                        leadingContent = {
                            Icon(painterResource(R.drawable.heart), contentDescription = null)
                        },
                        headlineContent = { Text(stringResource(string.reportBug)) },
                        supportingContent = { Text(stringResource(string.reportBugDesc)) },
                        modifier = Modifier
                            .clip(bottomListItemShape)
                            .clickable { setShowBugReport(true) },
                        colors = listItemColors
                    )
                }
                item { Spacer(Modifier.height(12.dp)) }
            }
            item {
                Card(
                    modifier = Modifier.padding(vertical = 14.dp),
                    shape = cardShape,
                    colors = CardDefaults.cardColors(containerColor = listItemColors.containerColor)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Spacer(
                                Modifier
                                    .clip(MaterialShapes.Cookie12Sided.toShape())
                                    .background(colorScheme.secondaryContainer)
                                    .padding(8.dp)
                                    .size(24.dp)
                            )
                            Icon(
                                painterResource(R.drawable.filled_info),
                                tint = colorScheme.onSecondaryContainer,
                                contentDescription = stringResource(string.information),
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Text(
                            stringResource(string.setAsDefault),
                            style = typography.headlineSmall
                        )
                        Text(
                            text = stringResource(string.setAsDefaultDesc),
                            style = typography.bodyLarge,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Row(
                            modifier = Modifier.align(Alignment.End),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                shapes = ButtonDefaults.shapes(),
                                onClick = { context.startActivity(appInfoIntent) }
                            ) {
                                Text(stringResource(string.settings))
                            }
                            FilledTonalButton(
                                shapes = ButtonDefaults.shapes(),
                                onClick = {
                                    uriHandler.openUri("https://github.com/PatrickJamesDev/WikiRandomizer-P#readme")
                                }
                            ) {
                                Text(stringResource(string.instructions))
                            }
                        }
                    }
                }
            }
            item { Spacer(Modifier.height(4.dp)) }
            item {
                FilledTonalButton(
                    onClick = { setShowResetSettingsDialog(true) },
                    shapes = ButtonDefaults.shapes(),
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = colorScheme.errorContainer,
                        contentColor = colorScheme.onErrorContainer
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                ) {
                    Icon(
                        painterResource(R.drawable.reset_settings),
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.size(ButtonDefaults.IconSpacing))
                    Text(stringResource(string.resetSettings))
                }
            }
            // Extra room so the last action (Reset settings) can scroll fully above the
            // navigation bar on edge-to-edge devices.
            item { Spacer(Modifier.height(72.dp)) }
            } else {
                // Search mode: a flat, tappable list of every setting. Switches toggle in place,
                // pickers open their dialog/sheet and sliders step to the next value.
                val strictLabel = when (preferencesState.topicStrictness) {
                    0 -> string.strictnessBroad
                    2 -> string.strictnessStrict
                    3 -> string.strictnessVeryStrict
                    else -> string.strictnessBalanced
                }
                val popularityLabel = when (preferencesState.popularityBias) {
                    -2 -> string.popularityObscureOnly
                    -1 -> string.popularityPreferObscure
                    1 -> string.popularityPreferPopular
                    2 -> string.popularityPopularOnly
                    else -> string.popularityNoPreference
                }
                val entries = buildList {
                    add(
                        SettingsSearchEntry(
                            context.getString(string.settingsReadingTopics),
                            context.getString(string.settingsReadingTopicsDesc),
                            "topics library shuffle random offline download", R.drawable.view_list
                        ) { onNavigateToReadingSettings() }
                    )
                    add(
                        SettingsSearchEntry(
                            context.getString(string.settingColorScheme),
                            if (color == Color.White) context.getString(string.colorSchemeDynamic)
                            else context.getString(string.colorSchemeColor),
                            "colour dynamic material you", R.drawable.palette
                        ) { setShowColorSchemeDialog(true) }
                    )
                    add(
                        SettingsSearchEntry(
                            context.getString(string.settingTheme),
                            themeMap[theme]?.second ?: theme,
                            "dark light system appearance", themeMap[theme]?.first ?: R.drawable.brightness_auto
                        ) { setShowThemeDialog(true) }
                    )
                    add(
                        SettingsSearchEntry(
                            context.getString(string.settingBlackTheme),
                            context.getString(string.settingBlackThemeDesc),
                            "dark amoled oled", R.drawable.dark_mode,
                            checked = preferencesState.blackTheme
                        ) { onAction(SettingsAction.SaveBlackTheme(!preferencesState.blackTheme)) }
                    )
                    add(
                        SettingsSearchEntry(
                            context.getString(string.settingWikipediaLanguage),
                            langCodeToName(preferencesState.lang),
                            "language articles wiki", R.drawable.translate
                        ) { setShowLanguageSheet(true) }
                    )
                    if (currentLocales != null) add(
                        SettingsSearchEntry(
                            context.getString(string.settingAppLanguage),
                            if (currentLocalesSize > 0) currentLocales.get(0).displayName
                            else context.getString(string.themeSystemDefault),
                            "locale interface ui", R.drawable.language
                        ) { setShowAppLocaleSheet(true) }
                    )
                    add(
                        SettingsSearchEntry(
                            context.getString(string.settingFontStyle),
                            fontStyleMap[fontStyle] ?: fontStyle,
                            "serif sans typeface text", R.drawable.serif
                        ) { onAction(SettingsAction.SaveFontStyle(if (fontStyle == "sans") "serif" else "sans")) }
                    )
                    add(
                        SettingsSearchEntry(
                            context.getString(string.settingFontSize),
                            "${preferencesState.fontSize}",
                            "text size bigger smaller", R.drawable.format_size
                        ) {
                            onAction(
                                SettingsAction.SaveFontSize(
                                    if (preferencesState.fontSize >= 22) 10 else preferencesState.fontSize + 1
                                )
                            )
                        }
                    )
                    add(
                        SettingsSearchEntry(
                            context.getString(string.settingArticleFormat),
                            if (preferencesState.renderMode == "html")
                                context.getString(string.articleFormatHtml)
                            else context.getString(string.articleFormatWikitext),
                            "html wikitext renderer", R.drawable.code
                        ) {
                            onAction(
                                SettingsAction.SaveRenderMode(
                                    if (preferencesState.renderMode == "html") "wikitext" else "html"
                                )
                            )
                        }
                    )
                    add(
                        SettingsSearchEntry(
                            context.getString(string.settingMenuSide),
                            if (preferencesState.menuSide == "right") context.getString(string.menuSideRight)
                            else context.getString(string.menuSideLeft),
                            "drawer navigation left right", R.drawable.menu
                        ) {
                            onAction(
                                SettingsAction.SaveMenuSide(
                                    if (preferencesState.menuSide == "right") "left" else "right"
                                )
                            )
                        }
                    )
                    add(
                        SettingsSearchEntry(
                            context.getString(string.settingStrictness),
                            context.getString(strictLabel),
                            "relevance filter match balanced strict", R.drawable.check
                        ) {
                            onAction(SettingsAction.SaveTopicStrictness((preferencesState.topicStrictness + 1) % 4))
                        }
                    )
                    add(
                        SettingsSearchEntry(
                            context.getString(string.settingPopularity),
                            context.getString(popularityLabel),
                            "obscure popular pageviews", R.drawable.upward
                        ) {
                            onAction(
                                SettingsAction.SavePopularityBias(
                                    if (preferencesState.popularityBias >= 2) -2 else preferencesState.popularityBias + 1
                                )
                            )
                        }
                    )
                    add(
                        SettingsSearchEntry(
                            context.getString(string.settingAvoidStubs),
                            context.getString(string.settingAvoidStubsDesc),
                            "short articles quality", R.drawable.expand_all,
                            checked = preferencesState.avoidStubs
                        ) { onAction(SettingsAction.SaveAvoidStubs(!preferencesState.avoidStubs)) }
                    )
                    add(
                        SettingsSearchEntry(
                            context.getString(string.settingPreferQuality),
                            context.getString(string.settingPreferQualityDesc),
                            "good featured", R.drawable.check,
                            checked = preferencesState.preferQuality
                        ) { onAction(SettingsAction.SavePreferQuality(!preferencesState.preferQuality)) }
                    )
                    add(
                        SettingsSearchEntry(
                            context.getString(string.settingImagesOnly),
                            context.getString(string.settingImagesOnlyDesc),
                            "pictures photos", R.drawable.image,
                            checked = preferencesState.onlyArticlesWithImages
                        ) {
                            onAction(
                                SettingsAction.SaveOnlyArticlesWithImages(!preferencesState.onlyArticlesWithImages)
                            )
                        }
                    )
                    switchItems.drop(1).forEach { item ->
                        add(
                            SettingsSearchEntry(
                                context.getString(item.label),
                                context.getString(item.description),
                                "switch toggle on off", item.icon,
                                checked = item.checked && item.enabled
                            ) {
                                if (item.enabled) onAction(item.actionConstructor(!item.checked))
                            }
                        )
                    }
                    add(
                        SettingsSearchEntry(
                            context.getString(string.settingReplayTutorial),
                            context.getString(string.settingReplayTutorialDesc),
                            "tour help onboarding", R.drawable.outline_info
                        ) { onReplayTutorial() }
                    )
                    add(
                        SettingsSearchEntry(
                            context.getString(string.settingDebugLogging),
                            context.getString(string.settingDebugLoggingDesc),
                            "logs diagnostics", R.drawable.search_history,
                            checked = preferencesState.debugLogging
                        ) { onAction(SettingsAction.SaveDebugLogging(!preferencesState.debugLogging)) }
                    )
                    add(
                        SettingsSearchEntry(
                            context.getString(string.settingViewDebugLog),
                            "Open the current debug log", "logs diagnostics share", R.drawable.expand_all
                        ) { setShowDebugLog(true) }
                    )
                    if (preferencesState.supporterMode) add(
                        SettingsSearchEntry(
                            context.getString(string.reportBug),
                            context.getString(string.reportBugDesc),
                            "bug issue crash logs feedback", R.drawable.heart
                        ) { setShowBugReport(true) }
                    )
                    add(
                        SettingsSearchEntry(
                            context.getString(string.setAsDefault),
                            context.getString(string.setAsDefaultDesc),
                            "links default browser", R.drawable.filled_info
                        ) { context.startActivity(appInfoIntent) }
                    )
                    add(
                        SettingsSearchEntry(
                            context.getString(string.resetSettings),
                            context.getString(string.resetSettingsDialogDesc),
                            "restore defaults", R.drawable.reset_settings
                        ) { setShowResetSettingsDialog(true) }
                    )
                }
                val query = settingsSearchQuery.trim().lowercase()
                val matches = entries.filter { entry ->
                    query.isBlank() || listOf(entry.title, entry.description, entry.keywords)
                        .any { it.lowercase().contains(query) }
                }
                if (matches.isEmpty()) {
                    item(key = "settings-search-empty") {
                        ListItem(
                            headlineContent = { Text(stringResource(string.noSettingsMatch)) },
                            supportingContent = { Text(stringResource(string.searchSettingsHint)) },
                            colors = listItemColors,
                            modifier = Modifier.clip(cardShape)
                        )
                    }
                } else {
                    items(matches, key = { "settings-search-${it.title}" }) { entry ->
                        ListItem(
                            leadingContent = {
                                Icon(painterResource(entry.icon), contentDescription = null)
                            },
                            headlineContent = { Text(entry.title) },
                            supportingContent = { Text(entry.description) },
                            trailingContent = {
                                when {
                                    entry.checked != null -> Switch(
                                        checked = entry.checked,
                                        onCheckedChange = { entry.action() },
                                        colors = switchColors
                                    )
                                    entry.value != null -> Text(entry.value)
                                }
                            },
                            colors = listItemColors,
                            modifier = Modifier
                                .clip(cardShape)
                                .clickable { entry.action() }
                        )
                    }
                }
            }
        }
    }
}

@Preview
@Composable
fun SettingsPreview() {
    val context = LocalContext.current
    val themeMap: Map<String, Pair<Int, String>> = remember {
        mapOf(
            "auto" to Pair(
                R.drawable.brightness_auto,
                context.getString(string.themeSystemDefault)
            ),
            "light" to Pair(R.drawable.light_mode, context.getString(string.themeLight)),
            "dark" to Pair(R.drawable.dark_mode, context.getString(string.themeDark))
        )
    }
    val reverseThemeMap: Map<String, String> = remember {
        mapOf(
            context.getString(string.themeSystemDefault) to "auto",
            context.getString(string.themeLight) to "light",
            context.getString(string.themeDark) to "dark"
        )
    }
    val fontStyleMap: Map<String, String> = remember {
        mapOf(
            "sans" to context.getString(string.fontStyleSansSerif),
            "serif" to context.getString(string.fontStyleSerif)
        )
    }
    val reverseFontStyleMap: Map<String, String> = remember {
        mapOf(
            context.getString(string.fontStyleSansSerif) to "sans",
            context.getString(string.fontStyleSerif) to "serif"
        )
    }
    val fontStyles = remember {
        listOf(
            context.getString(string.fontStyleSansSerif),
            context.getString(string.fontStyleSerif)
        )
    }
    WikiRandomizerPTheme {
        SettingsScreen(
            preferencesState = PreferencesState(),
            lastBackStackEntry = HomeSubscreen.Logo,
            recentLangs = emptyList(),
            languageSearchStr = "",
            languageSearchQuery = "",
            themeMap = themeMap,
            reverseThemeMap = reverseThemeMap,
            fontStyles = fontStyles,
            fontStyleMap = fontStyleMap,
            reverseFontStyleMap = reverseFontStyleMap,
            onAction = {},
            onHomeAction = {},
            onBack = {},
        )
    }
}

data class SettingsSwitchItem(
    val checked: Boolean,
    val icon: Int,
    val label: Int,
    val description: Int,
    val actionConstructor: (Boolean) -> SettingsAction,
    val enabled: Boolean = true
)