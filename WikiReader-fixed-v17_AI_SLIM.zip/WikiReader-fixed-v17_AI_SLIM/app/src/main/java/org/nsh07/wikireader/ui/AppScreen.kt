package org.nsh07.wikireader.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.AnchoredDraggableDefaults
import androidx.compose.foundation.gestures.AnchoredDraggableState
import androidx.compose.foundation.gestures.DraggableAnchors
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.anchoredDraggable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.animateTo
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.WindowInsetsSides
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.only
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.wrapContentHeight
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialogDefaults
import androidx.compose.material3.BasicAlertDialog
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.FloatingToolbarDefaults
import androidx.compose.material3.FloatingToolbarExitDirection
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.MaterialTheme.motionScheme
import androidx.compose.material3.MaterialTheme.typography
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScaffoldDefaults
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarResult
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.adaptive.currentWindowAdaptiveInfo
import androidx.compose.material3.rememberDrawerState
import androidx.compose.material3.rememberSearchBarState
import androidx.compose.material3.rememberWideNavigationRailState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.navigation.NavDestination
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navDeepLink
import androidx.navigation.toRoute
import androidx.window.core.layout.WindowSizeClass
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.serialization.Serializable

import org.nsh07.wikireader.R
import org.nsh07.wikireader.R.string
import org.nsh07.wikireader.BuildConfig
import org.nsh07.wikireader.FeatureFlags
import org.nsh07.wikireader.WikiRandomizerPApplication
import org.nsh07.wikireader.data.DebugLog
import org.nsh07.wikireader.data.SearchHistoryItem
import org.nsh07.wikireader.data.UpdateResult
import org.nsh07.wikireader.data.UpdateState
import org.nsh07.wikireader.data.UserLanguage
import org.nsh07.wikireader.ui.aboutScreen.AboutScreen
import org.nsh07.wikireader.ui.curatorsScreen.CuratorsScreenRoot
import org.nsh07.wikireader.ui.historyScreen.HistoryScreenRoot
import org.nsh07.wikireader.ui.highlightsScreen.HighlightsScreenRoot
import org.nsh07.wikireader.ui.homeScreen.AppHomeScreen
import org.nsh07.wikireader.ui.homeScreen.search.AppSearchBar
import org.nsh07.wikireader.ui.homeScreen.viewModel.ArticleTab
import org.nsh07.wikireader.ui.homeScreen.viewModel.HomeAction
import org.nsh07.wikireader.ui.homeScreen.viewModel.HomeScreenViewModel
import org.nsh07.wikireader.ui.homeScreen.viewModel.HomeSubscreen
import org.nsh07.wikireader.ui.savedArticlesScreen.SavedArticlesScreenRoot
import org.nsh07.wikireader.ui.settingsScreen.ReadingSettingsScreenRoot
import org.nsh07.wikireader.ui.settingsScreen.SettingsScreenRoot
import org.nsh07.wikireader.ui.kiwix.KiwixScreen
import org.nsh07.wikireader.ui.settingsScreen.viewModel.SettingsViewModel
import org.nsh07.wikireader.ui.randomTopicsScreen.RandomTopicsScreen
import org.nsh07.wikireader.ui.tutorial.WelcomeTutorial

@OptIn(ExperimentalMaterial3Api::class, ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun AppScreen(
    viewModel: HomeScreenViewModel,
    settingsViewModel: SettingsViewModel,
    modifier: Modifier = Modifier
) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    val preferencesState by settingsViewModel.preferencesState.collectAsStateWithLifecycle()

    val windowSizeClass = currentWindowAdaptiveInfo().windowSizeClass
    val appSearchBarState by viewModel.appSearchBarState.collectAsStateWithLifecycle()
    val homeScreenState by viewModel.homeScreenState.collectAsStateWithLifecycle()
    val searchListState by viewModel.searchListState.collectAsStateWithLifecycle()
    val showTutorial by viewModel.showTutorial.collectAsStateWithLifecycle()
    val tutorialStep by viewModel.tutorialStep.collectAsStateWithLifecycle()
    val topicExhausted by viewModel.topicExhausted.collectAsStateWithLifecycle()
    val donationPromptAt by viewModel.donationPromptAt.collectAsStateWithLifecycle()

    val backStack = viewModel.backStack

    val searchHistory by viewModel.searchHistoryFlow.collectAsState(emptyList())
    val recentLangs by viewModel.recentLangsFlow.collectAsStateWithLifecycle(emptyList())
    val userLangs by viewModel.userLangsFlow.collectAsState(
        listOf(
            UserLanguage(
                "en",
                "English",
                true
            )
        )
    )

    val searchBarState = rememberSearchBarState()
    val railState = rememberWideNavigationRailState()
    val drawerState = rememberDrawerState(DrawerValue.Closed)

    // Immersive reading really hides the phone status bar. It used to only change how the app
    // bars scroll, which left the status bar (clock/battery) permanently visible.
    val view = LocalView.current
    val imageOpen = backStack.lastOrNull() is org.nsh07.wikireader.ui.homeScreen.viewModel.HomeSubscreen.Image
    LaunchedEffect(preferencesState.immersiveMode, imageOpen) {
        val window = (view.context as? android.app.Activity)?.window ?: return@LaunchedEffect
        val controller = WindowCompat.getInsetsController(window, view)
        if (preferencesState.immersiveMode && !imageOpen) {
            controller.hide(WindowInsetsCompat.Type.statusBars())
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        } else {
            // The full-screen picture viewer manages the bars itself, so leave them alone there.
            if (!imageOpen) {
                controller.show(WindowInsetsCompat.Type.statusBars())
                controller.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_DEFAULT
            }
        }
    }
    val languageSearchStr by viewModel.languageSearchStr.collectAsStateWithLifecycle()
    val languageSearchQuery by viewModel.languageSearchQuery.collectAsState("")
    val motionScheme = motionScheme
    var showArticleLanguageSheet by rememberSaveable { mutableStateOf(false) }
    var deepLinkHandled by rememberSaveable { mutableStateOf(false) }
    var tabPanelOpen by rememberSaveable { mutableStateOf(false) }

    val searchBarScrollBehavior =
        if (
            !windowSizeClass.isHeightAtLeastBreakpoint(WindowSizeClass.HEIGHT_DP_MEDIUM_LOWER_BOUND) ||
            preferencesState.immersiveMode
        ) TopAppBarDefaults.enterAlwaysScrollBehavior()
        else TopAppBarDefaults.pinnedScrollBehavior()
    val floatingToolbarScrollBehaviour =
        if (
            !windowSizeClass.isHeightAtLeastBreakpoint(WindowSizeClass.HEIGHT_DP_MEDIUM_LOWER_BOUND) ||
            preferencesState.immersiveMode
        ) FloatingToolbarDefaults.exitAlwaysScrollBehavior(
            exitDirection = FloatingToolbarExitDirection.Bottom,
            snapAnimationSpec = motionScheme.defaultSpatialSpec()
        )
        else null
    val textFieldState = viewModel.textFieldState

    val snackBarHostState = viewModel.snackBarHostState

    // The old always-visible tab handle is gone. Teach the replacement once, the first time a
    // second tab is opened: the Tabs entry in the navigation drawer.
    val hintPrefs = remember { context.getSharedPreferences("ui_hints", 0) }
    var tabsHintShown by remember { mutableStateOf(hintPrefs.getBoolean("tabs_hint_shown", false)) }
    var lastTabCount by remember { mutableStateOf(homeScreenState.tabs.size) }
    LaunchedEffect(homeScreenState.tabs.size) {
        val count = homeScreenState.tabs.size
        if (count > lastTabCount && !tabsHintShown) {
            tabsHintShown = true
            hintPrefs.edit().putBoolean("tabs_hint_shown", true).apply()
            val result = snackBarHostState.showSnackbar(
                message = context.getString(R.string.tabsHint),
                actionLabel = context.getString(R.string.tabs),
                withDismissAction = true
            )
            if (result == SnackbarResult.ActionPerformed) tabPanelOpen = true
        }
        lastTabCount = count
    }

    val (showDeleteDialog, setShowDeleteDialog) = remember { mutableStateOf(false) }
    var historyItem: SearchHistoryItem? by remember { mutableStateOf(null) }

    val navController = rememberNavController()
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val kiwixStatus by viewModel.kiwixStatus.collectAsStateWithLifecycle()

    // When the user opted into Kiwix, the Random button (toolbar, pull-to-refresh and tutorial)
    // opens a random article from the ZIM instead of Wikipedia. Everything else keeps working.
    val onHomeAction: (HomeAction) -> Unit = { action ->
        if (action is HomeAction.LoadRandom && kiwixStatus.ready && kiwixStatus.useForRandom) {
            navController.navigate(KiwixReader(random = true)) {
                launchSingleTop = true
            }
        } else {
            viewModel.onAction(action)
        }
    }

    Box(modifier = modifier.fillMaxSize()) {
    val navigateTab: (Any) -> Unit = { route ->
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) { saveState = true }
            launchSingleTop = true
            restoreState = true
        }
    }

    // One background release check per process. The result is shared with About, so opening the
    // update entry never repeats the network round-trip. A failed check stays silent: it must never
    // interrupt reading or look like an app error.
    LaunchedEffect(Unit) {
        val app = context.applicationContext as? WikiRandomizerPApplication
            ?: return@LaunchedEffect
        if (UpdateState.checking.value) return@LaunchedEffect
        UpdateState.checking.value = true
        val result = app.container.updateChecker.checkForUpdate(BuildConfig.VERSION_NAME)
        UpdateState.checking.value = false
        UpdateState.lastCheckedAt.value = System.currentTimeMillis()
        when (result) {
            is UpdateResult.Available -> {
                UpdateState.available.value = result.info
                if (!UpdateState.promptedThisSession.value) {
                    UpdateState.promptedThisSession.value = true
                    val snackbar = snackBarHostState.showSnackbar(
                        message = context.getString(
                            R.string.updateAvailable,
                            result.info.version
                        ),
                        actionLabel = context.getString(R.string.viewUpdate),
                        withDismissAction = true
                    )
                    if (snackbar == SnackbarResult.ActionPerformed) navigateTab(AboutScreen)
                }
            }

            is UpdateResult.UpToDate -> DebugLog.i("Update", "app is up to date")
            is UpdateResult.Error -> DebugLog.w(
                "Update",
                "background update check failed: ${result.message}"
            )
        }
    }

    AppNavigationDrawer(
        state = railState,
        drawerState = drawerState,
        homeBackStackEntry = backStack.last(),
        windowSizeClass = windowSizeClass,
        backStackEntry = navBackStackEntry,
        historyEnabled = preferencesState.browsingHistory,
        isImageView = backStack.last() is HomeSubscreen.Image,
        onAboutClick = {
            navController.navigate(AboutScreen) {
                popUpTo(navController.graph.findStartDestination().id) {
                    saveState = true
                }
                launchSingleTop = true
                restoreState = true
            }
        },
        onHistoryClick = {
            navController.navigate(HistoryScreen) {
                popUpTo(navController.graph.findStartDestination().id) {
                    saveState = true
                }
                launchSingleTop = true
                restoreState = true
            }
        },
        onHomeClick = {
            if (navBackStackEntry?.destination?.hasRoute(HomeScreen::class) == true) {
                viewModel.onAction(HomeAction.LoadFeed(true))
            } else {
                navController.navigate(HomeScreen()) {
                    popUpTo(navController.graph.findStartDestination().id) {
                        saveState = true
                    }
                    launchSingleTop = true
                    restoreState = true
                }
            }
        },
        onSavedArticlesClick = {
            navController.navigate(SavedArticlesScreen) {
                popUpTo(navController.graph.findStartDestination().id) {
                    saveState = true
                }
                launchSingleTop = true
                restoreState = true
            }
        },
        onHighlightsClick = {
            navController.navigate(HighlightsScreen) {
                popUpTo(navController.graph.findStartDestination().id) {
                    saveState = true
                }
                launchSingleTop = true
                restoreState = true
            }
        },
        onSettingsClick = {
            navController.navigate(SettingsScreen) {
                popUpTo(navController.graph.findStartDestination().id) {
                    saveState = true
                }
                launchSingleTop = true
                restoreState = true
            }
        },
        onCuratorsClick = {
            navController.navigate(CuratorsScreen) {
                popUpTo(navController.graph.findStartDestination().id) {
                    saveState = true
                }
                launchSingleTop = true
                restoreState = true
            }
        },
        onTabsClick = { tabPanelOpen = true },
        menuOnRight = preferencesState.menuSide == "right",
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.surface)
    ) {
        val compactWindow =
            !windowSizeClass.isWidthAtLeastBreakpoint(WindowSizeClass.WIDTH_DP_MEDIUM_LOWER_BOUND)
        NavHost(
            navController = navController,
            startDestination = HomeScreen(),
            enterTransition = {
                if (compactWindow)
                    slideInHorizontally(initialOffsetX = { it })
                else
                    fadeIn(animationSpec = tween(220, delayMillis = 90)) +
                            scaleIn(
                                initialScale = 0.92f,
                                animationSpec = tween(220, delayMillis = 90)
                            )
            },
            exitTransition = {
                if (compactWindow)
                    slideOutHorizontally(targetOffsetX = { -it / 4 })
                else
                    fadeOut(animationSpec = tween(90))
            },
            popEnterTransition = {
                if (compactWindow)
                    slideInHorizontally(initialOffsetX = { -it / 4 }) + fadeIn()
                else
                    fadeIn(animationSpec = tween(220, delayMillis = 90)) +
                            scaleIn(
                                initialScale = 0.92f,
                                animationSpec = tween(220, delayMillis = 90)
                            )
            },
            popExitTransition = {
                if (compactWindow)
                    slideOutHorizontally(targetOffsetX = { it })
                else
                    fadeOut(animationSpec = tween(90))
            }
        ) {
            composable<HomeScreen>(
                deepLinks = listOf(
                    navDeepLink { uriPattern = "{lang}.m.wikipedia.org/wiki/{query}" },
                    navDeepLink { uriPattern = "{lang}.wikipedia.org/wiki/{query}" }
                )
            ) { backStackEntry ->
                val uriQuery = remember { backStackEntry.arguments?.getString("query") }
                LaunchedEffect(uriQuery) {
                    if (uriQuery != null && !deepLinkHandled) {
                        deepLinkHandled = true
                        val lang = backStackEntry.arguments?.getString("lang")
                        viewModel.onAction(HomeAction.StopAll)
                        delay(500) // Avoids a race condition where the hostname might not get updated in time
                        viewModel.onAction(HomeAction.LoadPage(uriQuery, lang = lang))
                    }
                }

                if (showDeleteDialog)
                    DeleteHistoryItemDialog(
                        historyItem,
                        setShowDeleteDialog,
                        viewModel::removeSearchHistoryItem
                    )

                Scaffold(
                    topBar = {
                        AnimatedVisibility(
                            backStack.last() !is HomeSubscreen.Image,
                            enter = slideInVertically(
                                motionScheme.defaultSpatialSpec(),
                                initialOffsetY = { -it }
                            ) + expandVertically(motionScheme.defaultSpatialSpec()),
                            exit = fadeOut()
                        ) {
                            AppSearchBar(
                                appSearchBarState = appSearchBarState,
                                searchBarState = searchBarState,
                                preferencesState = preferencesState,
                                textFieldState = textFieldState,
                                userLangs = userLangs,
                                recentLangs = recentLangs,
                                searchHistory = searchHistory,
                                scrollBehavior = searchBarScrollBehavior,
                                searchBarEnabled = !showArticleLanguageSheet,
                                searchListState = searchListState,
                                windowSizeClass = windowSizeClass,
                                languageSearchStr = languageSearchStr,
                                languageSearchQuery = languageSearchQuery,
                                onAction = onHomeAction,
                                onSettingsAction = settingsViewModel::onAction,
                                onSearchBarExpandedChange = {
                                    scope.launch {
                                        if (it) searchBarState.animateToExpanded()
                                        else searchBarState.animateToCollapsed()
                                    }
                                },
                                onNavigateToRandomTopics = {
                                    navController.navigate(RandomTopicsScreen) {
                                        launchSingleTop = true
                                    }
                                },
                                clearHistory = {
                                    historyItem = null
                                    setShowDeleteDialog(true)
                                },
                                removeHistoryItem = {
                                    historyItem = it
                                    setShowDeleteDialog(true)
                                },
                                onMenuIconClicked = {
                                    scope.launch {
                                        if (compactWindow) drawerState.open()
                                        else railState.expand()
                                    }
                                }
                            )
                        }
                    },
                    // Keep snackbars above the floating reading toolbar instead of covering it.
                    snackbarHost = {
                        SnackbarHost(
                            snackBarHostState,
                            modifier = Modifier.padding(bottom = 88.dp)
                        )
                    },
                    contentWindowInsets =
                        if (!compactWindow)
                            ScaffoldDefaults.contentWindowInsets
                                .only(WindowInsetsSides.Top + WindowInsetsSides.Bottom + WindowInsetsSides.End)
                        else ScaffoldDefaults.contentWindowInsets,
                    modifier = (if (floatingToolbarScrollBehaviour != null)
                        Modifier
                            .fillMaxSize()
                            .nestedScroll(searchBarScrollBehavior.nestedScrollConnection)
                            .nestedScroll(floatingToolbarScrollBehaviour)
                    else
                        Modifier
                            .fillMaxSize()
                            .nestedScroll(searchBarScrollBehavior.nestedScrollConnection)
                    )
                ) { insets ->
                    AppHomeScreen(
                        backStack = backStack,
                        homeScreenState = homeScreenState,
                        preferencesState = preferencesState,
                        recentLangs = recentLangs,
                        floatingToolbarScrollBehaviour = floatingToolbarScrollBehaviour,
                        languageSearchStr = languageSearchStr,
                        languageSearchQuery = languageSearchQuery,
                        showLanguageSheet = showArticleLanguageSheet,
                        deepLinkHandled = deepLinkHandled,
                        onAction = onHomeAction,
                        onSettingsAction = settingsViewModel::onAction,
                        onNavigateToRandomTopics = {
                            navController.navigate(RandomTopicsScreen) {
                                launchSingleTop = true
                            }
                        },
                        setShowArticleLanguageSheet = { showArticleLanguageSheet = it },
                        insets = insets,
                        windowSizeClass = windowSizeClass,
                        modifier = Modifier.fillMaxSize()
                    )

                    AnimatedVisibility(
                        backStack.last() !is HomeSubscreen.Image,
                        enter = fadeIn(motionScheme.slowEffectsSpec()),
                        exit = fadeOut(motionScheme.fastEffectsSpec())
                    ) {
                        StatusBarProtection()
                    }
                }

                // First-launch tour (and "Welcome tutorial" in Settings). It is a dialog, so it also
                // covers the search bar; it is only shown while the home screen is the current page.
                if (showTutorial && navBackStackEntry?.destination?.hasRoute(HomeScreen::class) == true) {
                    WelcomeTutorial(
                        step = tutorialStep,
                        onStepChange = viewModel::setTutorialStep,
                        onOpenTopics = {
                            navController.navigate(RandomTopicsScreen) {
                                launchSingleTop = true
                            }
                        },
                        onTryRandom = { onHomeAction(HomeAction.LoadRandom) },
                        onOpenSettings = {
                            navController.navigate(SettingsScreen) {
                                launchSingleTop = true
                            }
                        },
                        onFinish = viewModel::finishTutorial
                    )
                }

                // Every article in the selected topics has been read: offer a reset instead of
                // silently showing an error page.
                if (topicExhausted) {
                    BasicAlertDialog(onDismissRequest = viewModel::dismissTopicExhausted) {
                        Surface(
                            shape = MaterialTheme.shapes.extraLarge,
                            tonalElevation = AlertDialogDefaults.TonalElevation
                        ) {
                            Column(Modifier.padding(24.dp)) {
                                Text(
                                    text = stringResource(R.string.topicExhaustedTitle),
                                    style = typography.headlineSmall
                                )
                                Spacer(Modifier.height(12.dp))
                                Text(
                                    text = stringResource(R.string.topicExhaustedDesc),
                                    style = typography.bodyMedium
                                )
                                Spacer(Modifier.height(24.dp))
                                Row(
                                    horizontalArrangement = Arrangement.End,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    TextButton(onClick = viewModel::dismissTopicExhausted) {
                                        Text(stringResource(R.string.no))
                                    }
                                    TextButton(onClick = viewModel::resetTopicHistoryAndReload) {
                                        Text(stringResource(R.string.yes))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            composable<SavedArticlesScreen> {
                SavedArticlesScreenRoot(
                    imageBackground = preferencesState.imageBackground,
                    openSavedArticle = { pageId: Int, lang: String ->
                        navController.navigateUp()
                        viewModel.onAction(HomeAction.LoadSavedArticle(pageId, lang))
                    },
                    onBack = navController::navigateUp
                )
            }

            composable<HighlightsScreen> {
                HighlightsScreenRoot(
                    openArticle = { title, lang ->
                        viewModel.onAction(HomeAction.LoadPage(title, lang))
                        navController.navigate(HomeScreen()) {
                            popUpTo(navController.graph.findStartDestination().id) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    },
                    onBack = navController::navigateUp
                )
            }

            composable<HistoryScreen> {
                HistoryScreenRoot(
                    imageBackground = preferencesState.imageBackground,
                    openArticle = { title, lang ->
                        viewModel.onAction(HomeAction.LoadPage(title, lang))
                        navController.navigateUp()
                    },
                    onBack = navController::navigateUp
                )
            }

            composable<SettingsScreen> {
                SettingsScreenRoot(
                    preferencesState = preferencesState,
                    lastBackStackEntry = backStack.last(),
                    recentLangs = recentLangs,
                    languageSearchStr = languageSearchStr,
                    languageSearchQuery = languageSearchQuery,
                    onHomeAction = onHomeAction,
                    onNavigateToReadingSettings = {
                        navController.navigate(ReadingSettingsScreen) {
                            launchSingleTop = true
                        }
                    },
                    onReplayTutorial = {
                        viewModel.replayTutorial()
                        navController.navigateUp()
                    },
                    onGetLibraryStats = { viewModel.getLibraryStats() },
                    onSetTopicEnabled = { topic, enabled ->
                        viewModel.setTopicEnabled(topic, enabled)
                    },
                    onBack = navController::navigateUp
                )
            }

            composable<CuratorsScreen> {
                CuratorsScreenRoot(
                    openArticle = { title, lang ->
                        viewModel.onAction(HomeAction.LoadPage(title, lang))
                        navController.navigate(HomeScreen()) {
                            popUpTo(navController.graph.findStartDestination().id) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    },
                    onBack = navController::navigateUp
                )
            }

            composable<AboutScreen> {
                AboutScreen(onBack = navController::navigateUp)
            }

            composable<ReadingSettingsScreen> {
                ReadingSettingsScreenRoot(
                    onNavigateToRandomTopics = {
                        navController.navigate(RandomTopicsScreen) {
                            launchSingleTop = true
                        }
                    },
                    onGetLibraryStats = { viewModel.getLibraryStats() },
                    kiwixStatus = kiwixStatus,
                    onSelectKiwix = viewModel::selectKiwixDatabase,
                    onRemoveKiwix = viewModel::removeKiwixDatabase,
                    onSetKiwixForRandom = viewModel::setKiwixForRandom,
                    onOpenKiwixReader = {
                        navController.navigate(KiwixReader()) { launchSingleTop = true }
                    },
                    onBack = navController::navigateUp
                )
            }

            composable<KiwixReader> { entry ->
                val route = entry.toRoute<KiwixReader>()
                KiwixScreen(
                    repository = viewModel.kiwixRepository,
                    startPath = route.path.takeIf { it.isNotBlank() },
                    random = route.random,
                    onBack = navController::navigateUp
                )
            }

            composable<RandomTopicsScreen> {
                val indexState by viewModel.indexState.collectAsStateWithLifecycle()
                RandomTopicsScreen(
                    onGetTopics = { viewModel.getRandomTopics() },
                    onSaveTopics = { topics, force ->
                        // Persist the selection (and enabled flags) before building, and await it:
                        // starting the build first could race with the save and pick up the old set.
                        viewModel.saveTopicSelection(topics)
                        viewModel.startIndexBuild(topics, force)
                    },
                    indexState = indexState,
                    onCancelBuild = viewModel::cancelIndexBuild,
                    onResolveInterests = { text, status -> viewModel.resolveInterests(text, status) },
                    onGetInterestText = { viewModel.getInterestText() },
                    onSaveInterestText = { viewModel.saveInterestText(it) },
                    onGetLibraryStats = { viewModel.getLibraryStats() },
                    onSetTopicEnabled = { topic, enabled -> viewModel.setTopicEnabled(topic, enabled) },
                    onRemoveTopic = { topic -> viewModel.removeTopicFromLibrary(topic) },
                    onEstimateOffline = { count -> viewModel.estimateOfflineDownload(count) },
                    onDownloadOffline = { count, progress ->
                        viewModel.downloadOfflineArticles(count, progress)
                    },
                    onGetOfflineStats = { viewModel.getOfflineStats() },
                    onDeleteOffline = { viewModel.deleteOfflineArticles() },
                    onSaveTopicHints = { viewModel.saveTopicHints(it) },
                    onResetSeen = { viewModel.resetSeenArticles() },
                    onStartBrowsing = {
                        // Do not cancel the build: it continues behind the reader.
                        navController.navigate(HomeScreen()) {
                            popUpTo(navController.graph.findStartDestination().id) {
                                saveState = true
                            }
                            launchSingleTop = true
                            restoreState = true
                        }
                    },
                    onBack = navController::navigateUp
                )
            }
        }
    }
    val currentArticle = backStack.lastOrNull() as? HomeSubscreen.Article
    // Image-less articles get a "Find images" shortcut in the tab panel. The lead photo and the
    // body pictures are both checked, so an article with illustrations but no infobox image is
    // not flagged.
    val articleHasImages = currentArticle?.let { article ->
        article.photo != null || article.thumbnail != null ||
                article.extract.any { section ->
                    section.any { block ->
                        val text = block.text.trimStart()
                        text.startsWith("[[File:", ignoreCase = true) ||
                                text.startsWith("<gallery", ignoreCase = true)
                    }
                }
    } ?: true
    val imageSearchTitle = currentArticle?.title?.takeIf {
        !articleHasImages && it.isNotBlank() && it != "Error"
    }
    val uriHandler = androidx.compose.ui.platform.LocalUriHandler.current
    ArticleTabPanel(
        open = tabPanelOpen,
        onOpenChange = { tabPanelOpen = it },
        currentRoute = navBackStackEntry?.destination,
        tabs = homeScreenState.tabs,
        activeTabId = homeScreenState.activeTabId,
        canGoBack = homeScreenState.canGoBack,
        canGoForward = homeScreenState.canGoForward,
        canOpenInBrowser = currentArticle != null && currentArticle.title != "Error",
        imageSearchTitle = imageSearchTitle,
        onFindImages = { title ->
            val query = java.net.URLEncoder.encode("$title Wikipedia", "UTF-8")
            uriHandler.openUri("https://www.google.com/search?tbm=isch&q=$query")
        },
        onOpenInBrowser = {
            currentArticle?.let {
                viewModel.onAction(
                    HomeAction.OpenInBrowser(
                        title = it.title,
                        lang = it.currentLang ?: preferencesState.lang
                    )
                )
            }
        },
        onBack = { viewModel.onAction(HomeAction.NavigateBack) },
        onForward = { viewModel.onAction(HomeAction.NavigateForward) },
        onSelectTab = { viewModel.onAction(HomeAction.SwitchTab(it)) },
        onCloseTab = { viewModel.onAction(HomeAction.CloseTab(it)) },
        onNewTab = { viewModel.onAction(HomeAction.NewTab) },
        onHome = { navigateTab(HomeScreen()) },
        onSaved = { navigateTab(SavedArticlesScreen) },
        onHighlights = { navigateTab(HighlightsScreen) },
        onHistory = { navigateTab(HistoryScreen) },
        onCurators = { navigateTab(CuratorsScreen) },
        onSettings = { navigateTab(SettingsScreen) },
        onAbout = { navigateTab(AboutScreen) }
    )

    // Optional donation milestone (disabled unless the user turns it on in Settings).
    donationPromptAt?.let { milestone ->
        BasicAlertDialog(onDismissRequest = viewModel::dismissDonationPrompt) {
            Surface(
                shape = MaterialTheme.shapes.extraLarge,
                tonalElevation = AlertDialogDefaults.TonalElevation
            ) {
                Column(Modifier.padding(24.dp)) {
                    Text(
                        text = stringResource(R.string.donationPromptTitle),
                        style = typography.headlineSmall
                    )
                    Spacer(Modifier.height(12.dp))
                    Text(
                        text = stringResource(R.string.donationPromptDesc, milestone),
                        style = typography.bodyMedium
                    )
                    Spacer(Modifier.height(24.dp))
                    Row(
                        horizontalArrangement = Arrangement.End,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        TextButton(onClick = viewModel::dismissDonationPrompt) {
                            Text(stringResource(R.string.later))
                        }
                        TextButton(
                            onClick = {
                                viewModel.dismissDonationPrompt()
                                uriHandler.openUri("https://github.com/PatrickJamesDev")
                            }
                        ) {
                            Text(stringResource(R.string.donateNow))
                        }
                    }
                }
            }
        }
    }
    }
}

/**
 * The article tab panel. It follows the finger in from the right edge, shows every open article
 * tab, and also carries unlimited back/forward plus the app shortcuts that used to live in the
 * narrow rail. It overlays the article instead of resizing it, so opening it never reflows text.
 * There is no permanent handle: the panel is reachable by swiping from the edge or from the Tabs
 * entry in the navigation drawer.
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalMaterial3ExpressiveApi::class)
@Composable
private fun ArticleTabPanel(
    open: Boolean,
    onOpenChange: (Boolean) -> Unit,
    currentRoute: NavDestination?,
    tabs: List<ArticleTab>,
    activeTabId: Long?,
    canGoBack: Boolean,
    canGoForward: Boolean,
    canOpenInBrowser: Boolean,
    imageSearchTitle: String? = null,
    onFindImages: (String) -> Unit = {},
    onOpenInBrowser: () -> Unit,
    onBack: () -> Unit,
    onForward: () -> Unit,
    onSelectTab: (Long) -> Unit,
    onCloseTab: (Long) -> Unit,
    onNewTab: () -> Unit,
    onHome: () -> Unit,
    onSaved: () -> Unit,
    onHighlights: () -> Unit,
    onHistory: () -> Unit,
    onCurators: () -> Unit,
    onSettings: () -> Unit,
    onAbout: () -> Unit
) {
    val density = LocalDensity.current
    val dragState = remember {
        AnchoredDraggableState(initialValue = TabPanelValue.Closed)
    }
    var anchorsReady by remember { mutableStateOf(false) }
    val flingBehavior = AnchoredDraggableDefaults.flingBehavior(
        dragState,
        { distance -> distance * 0.5f },
        tween(260)
    )

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val panelWidth = (maxWidth * 0.88f).coerceAtMost(320.dp)
        val panelWidthPx = with(density) { panelWidth.toPx() }

        LaunchedEffect(panelWidthPx) {
            dragState.updateAnchors(
                DraggableAnchors {
                    TabPanelValue.Closed at panelWidthPx
                    TabPanelValue.Open at 0f
                }
            )
            anchorsReady = true
        }

        LaunchedEffect(open, panelWidthPx, anchorsReady) {
            val target = if (open) TabPanelValue.Open else TabPanelValue.Closed
            if (anchorsReady && dragState.currentValue != target &&
                !dragState.isAnimationRunning
            ) {
                dragState.animateTo(target)
            }
        }

        // The drawer's Tabs entry and the close button set `open`; a finger drag settles the
        // anchored state, so mirror its settled value back into the hoisted state.
        LaunchedEffect(dragState) {
            snapshotFlow { dragState.settledValue }.collect { value ->
                onOpenChange(value == TabPanelValue.Open)
            }
        }

        Box(
            Modifier
                .fillMaxSize()
                .drawBehind {
                    val offset = if (anchorsReady) dragState.offset else if (open) 0f else panelWidthPx
                    val fraction = if (offset.isNaN()) 0f
                    else (1f - offset / panelWidthPx).coerceIn(0f, 1f)
                    drawRect(Color.Black.copy(alpha = 0.32f * fraction))
                }
                // The scrim is decorative: when closed it must not sit in the accessibility
                // tree as an invisible full-screen clickable node, and TalkBack users can
                // dismiss the panel with the visible close button instead. It also must not
                // install a full-screen tap detector while closed, or it would swallow every
                // touch in the app (the panel is composed above the whole screen).
                .then(
                    if (open) Modifier
                        .clearAndSetSemantics {}
                        .pointerInput(Unit) {
                            detectTapGestures { onOpenChange(false) }
                        }
                    else Modifier
                )
        )

        Surface(
            color = MaterialTheme.colorScheme.surfaceContainer,
            tonalElevation = 6.dp,
            shadowElevation = 10.dp,
            shape = RoundedCornerShape(topStart = 28.dp, bottomStart = 28.dp),
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .width(panelWidth)
                .fillMaxHeight()
                // graphicsLayer keeps the panel on the render thread: laying it out with
                // Modifier.offset on every animation frame made the opening animation jitter.
                .graphicsLayer {
                    val offset = if (anchorsReady) dragState.offset
                    else if (open) 0f else panelWidthPx
                    translationX = if (offset.isNaN()) panelWidthPx else offset
                }
                .anchoredDraggable(
                    dragState,
                    Orientation.Horizontal,
                    flingBehavior = flingBehavior
                )
        ) {
                Column(
                    Modifier
                        .fillMaxSize()
                        .statusBarsPadding()
                        .navigationBarsPadding()
                        .padding(horizontal = 12.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(top = 16.dp, bottom = 4.dp)
                    ) {
                        Text(
                            stringResource(R.string.tabs),
                            style = typography.headlineSmall,
                            modifier = Modifier.weight(1f)
                        )
                        IconButton(onClick = { onOpenChange(false) }) {
                            Icon(
                                painterResource(R.drawable.clear),
                                contentDescription = stringResource(R.string.closeTabPanel)
                            )
                        }
                    }

                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        FilledTonalIconButton(
                            onClick = { onOpenChange(false); onBack() },
                            enabled = canGoBack,
                            shapes = IconButtonDefaults.shapes()
                        ) {
                            Icon(
                                painterResource(R.drawable.arrow_back),
                                contentDescription = stringResource(R.string.articleBack)
                            )
                        }
                        FilledTonalIconButton(
                            onClick = { onOpenChange(false); onForward() },
                            enabled = canGoForward,
                            shapes = IconButtonDefaults.shapes()
                        ) {
                            Icon(
                                painterResource(R.drawable.arrow_forward),
                                contentDescription = stringResource(R.string.articleForward)
                            )
                        }
                        FilledTonalIconButton(
                            onClick = { onOpenChange(false); onOpenInBrowser() },
                            enabled = canOpenInBrowser,
                            shapes = IconButtonDefaults.shapes()
                        ) {
                            Icon(
                                painterResource(R.drawable.open_in_browser),
                                contentDescription = stringResource(R.string.openInBrowser)
                            )
                        }
                        Spacer(Modifier.weight(1f))
                        TextButton(onClick = { onOpenChange(false); onNewTab() }) {
                            Icon(
                                painterResource(R.drawable.add),
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(stringResource(R.string.newTab))
                        }
                    }

                    Spacer(Modifier.height(6.dp))
                    HorizontalDivider()

                    if (tabs.isEmpty()) {
                        Box(
                            Modifier
                                .fillMaxWidth()
                                .weight(1f),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    painterResource(R.drawable.tab),
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(48.dp)
                                )
                                Spacer(Modifier.height(10.dp))
                                Text(
                                    stringResource(R.string.noTabs),
                                    style = typography.titleMedium
                                )
                                Text(
                                    stringResource(R.string.noTabsDesc),
                                    style = typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
                                )
                            }
                        }
                    } else {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxWidth()
                                .weight(1f)
                        ) {
                            items(tabs, key = { it.id }) { tab ->
                                ListItem(
                                    leadingContent = {
                                        Icon(
                                            painterResource(R.drawable.tab),
                                            contentDescription = null
                                        )
                                    },
                                    headlineContent = {
                                        Text(
                                            tab.title,
                                            maxLines = 2,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    },
                                    supportingContent = {
                                        Text(tab.lang.uppercase())
                                    },
                                    trailingContent = {
                                        IconButton(onClick = { onCloseTab(tab.id) }) {
                                            Icon(
                                                painterResource(R.drawable.clear),
                                                contentDescription = stringResource(R.string.closeTab)
                                            )
                                        }
                                    },
                                    colors = if (tab.id == activeTabId)
                                        ListItemDefaults.colors(
                                            containerColor = MaterialTheme.colorScheme.secondaryContainer
                                        )
                                    else ListItemDefaults.colors(containerColor = Color.Transparent),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .animateItem()
                                        .clip(RoundedCornerShape(16.dp))
                                        .clickable {
                                            onOpenChange(false)
                                            onSelectTab(tab.id)
                                        }
                                )
                            }
                        }
                    }

                    HorizontalDivider()
                    Text(
                        stringResource(R.string.app),
                        style = typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(start = 12.dp, top = 10.dp, bottom = 4.dp)
                    )
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(max = 260.dp)
                    ) {
                        item {
                            AppShortcut(
                                label = stringResource(R.string.home),
                                icon = R.drawable.filled_home,
                                selected = currentRoute?.hasRoute(HomeScreen::class) == true,
                                onClick = { onOpenChange(false); onHome() }
                            )
                        }
                        // Only for articles that have no lead picture and no body pictures.
                        if (imageSearchTitle != null) {
                            item {
                                AppShortcut(
                                    label = stringResource(R.string.findImages),
                                    icon = R.drawable.image,
                                    selected = false,
                                    onClick = {
                                        onOpenChange(false)
                                        onFindImages(imageSearchTitle)
                                    }
                                )
                            }
                        }
                        item {
                            AppShortcut(
                                label = stringResource(R.string.saved),
                                icon = R.drawable.filled_download_done,
                                selected = currentRoute?.hasRoute(SavedArticlesScreen::class) == true,
                                onClick = { onOpenChange(false); onSaved() }
                            )
                        }
                        item {
                            AppShortcut(
                                label = stringResource(R.string.savedHighlights),
                                icon = R.drawable.highlight,
                                selected = currentRoute?.hasRoute(HighlightsScreen::class) == true,
                                onClick = { onOpenChange(false); onHighlights() }
                            )
                        }
                        item {
                            AppShortcut(
                                label = stringResource(R.string.history),
                                icon = R.drawable.history,
                                selected = currentRoute?.hasRoute(HistoryScreen::class) == true,
                                onClick = { onOpenChange(false); onHistory() }
                            )
                        }
                        // Keep the Curators entry wired but hidden while the feature is not ready.
                        if (FeatureFlags.CURATORS_ENABLED) {
                            item {
                                AppShortcut(
                                    label = stringResource(R.string.curators),
                                    icon = R.drawable.groups,
                                    selected = currentRoute?.hasRoute(CuratorsScreen::class) == true,
                                    onClick = { onOpenChange(false); onCurators() }
                                )
                            }
                        }
                        item {
                            AppShortcut(
                                label = stringResource(R.string.settings),
                                icon = R.drawable.filled_settings,
                                selected = currentRoute?.hasRoute(SettingsScreen::class) == true ||
                                    currentRoute?.hasRoute(ReadingSettingsScreen::class) == true,
                                onClick = { onOpenChange(false); onSettings() }
                            )
                        }
                        item {
                            AppShortcut(
                                label = stringResource(R.string.about),
                                icon = R.drawable.filled_info,
                                selected = currentRoute?.hasRoute(AboutScreen::class) == true,
                                onClick = { onOpenChange(false); onAbout() }
                            )
                        }
                    }
                }
            }

        // No permanent handle: a narrow strip at the physical right edge starts the same
        // finger-following drag. A horizontal-only drag keeps vertical scrolling untouched.
        if (!open) {
            Box(
                Modifier
                    .align(Alignment.CenterEnd)
                    .fillMaxHeight()
                    .width(24.dp)
                    .anchoredDraggable(
                    dragState,
                    Orientation.Horizontal,
                    flingBehavior = flingBehavior
                )
            )
        }
    }
}

private enum class TabPanelValue { Closed, Open }

@Composable
private fun AppShortcut(
    label: String,
    icon: Int,
    selected: Boolean,
    onClick: () -> Unit
) {
    ListItem(
        headlineContent = { Text(label) },
        leadingContent = {
            Icon(
                painterResource(icon),
                contentDescription = null
            )
        },
        colors = if (selected)
            ListItemDefaults.colors(
                containerColor = MaterialTheme.colorScheme.secondaryContainer
            )
        else ListItemDefaults.colors(containerColor = Color.Transparent),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
    )
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun DeleteHistoryItemDialog(
    item: SearchHistoryItem?,
    setShowDeleteDialog: (Boolean) -> Unit,
    removeHistoryItem: (SearchHistoryItem?) -> Unit
) {
    BasicAlertDialog(
        onDismissRequest = { setShowDeleteDialog(false) }
    ) {
        val titleText =
            if (item != null) stringResource(string.dialogDeleteSearchHistory)
            else stringResource(string.dialogDeleteSearchHistoryDesc)
        val descText =
            if (item != null) stringResource(string.dialogDeleteHistoryItem, item.query)
            else stringResource(string.dialogDeleteHistoryItemDesc)

        Surface(
            modifier = Modifier
                .wrapContentWidth()
                .wrapContentHeight(),
            shape = MaterialTheme.shapes.extraLarge,
            tonalElevation = AlertDialogDefaults.TonalElevation
        ) {
            Column(modifier = Modifier.padding(24.dp)) {
                Text(
                    text = titleText,
                    style = typography.headlineSmall
                )
                Spacer(modifier = Modifier.padding(16.dp))
                Text(
                    text = descText,
                    style = typography.bodyMedium
                )
                Spacer(modifier = Modifier.height(24.dp))
                Row(modifier = Modifier.align(Alignment.End)) {
                    TextButton(
                        shapes = ButtonDefaults.shapes(),
                        onClick = { setShowDeleteDialog(false) }) {
                        Text(text = stringResource(string.cancel))
                    }
                    TextButton(shapes = ButtonDefaults.shapes(), onClick = {
                        setShowDeleteDialog(false)
                        removeHistoryItem(item)
                    }) {
                        Text(text = stringResource(string.delete))
                    }
                }
            }
        }
    }
}

@Composable
private fun StatusBarProtection(
    color: Color = MaterialTheme.colorScheme.surface,
    heightProvider: () -> Float = calculateGradientHeight(),
) {
    Canvas(Modifier.fillMaxSize()) {
        val calculatedHeight = heightProvider()
        val gradient = Brush.verticalGradient(
            colors = listOf(
                color.copy(alpha = 1f),
                color.copy(alpha = 0.7f),
                Color.Transparent
            ),
            startY = 0f,
            endY = calculatedHeight
        )
        drawRect(
            brush = gradient,
            size = Size(size.width, calculatedHeight),
        )
    }
}

@Composable
fun calculateGradientHeight(): () -> Float {
    val statusBars = WindowInsets.statusBars
    val density = LocalDensity.current
    return { statusBars.getTop(density).times(1.2f) }
}

@Serializable
data class HomeScreen(
    val lang: String? = null,
    val query: String? = null
)

@Serializable
object SavedArticlesScreen

@Serializable
object HighlightsScreen

@Serializable
object HistoryScreen

@Serializable
object SettingsScreen

@Serializable
object CuratorsScreen

@Serializable
object AboutScreen

@Serializable
object ReadingSettingsScreen

@Serializable
object RandomTopicsScreen

/** Opens the Kiwix/ZIM reader, either at a known entry or at a random article. */
@Serializable
data class KiwixReader(
    val random: Boolean = false,
    /** Empty means "start at the archive's main page". */
    val path: String = ""
)
