package org.nsh07.wikireader.data

import kotlinx.coroutines.CoroutineDispatcher
import kotlinx.coroutines.withContext
import org.nsh07.wikireader.data.WikiApiCategorySearchResponse
import org.nsh07.wikireader.network.WikipediaApiService
import java.time.LocalDate
import java.time.format.DateTimeFormatter

interface WikipediaRepository {
    suspend fun getPrefixSearchResults(query: String): WikiApiPrefixSearchResults
    suspend fun getSearchResults(query: String): WikiApiSearchResults
    suspend fun getPageData(query: String): WikiApiPageData
    suspend fun getPageContent(title: String): String
    /** Fully rendered article HTML (REST API), used when the user selects the HTML renderer. */
    suspend fun getPageHtml(title: String): String
    suspend fun getRandomResult(): WikiApiPageData
    suspend fun getCategoryMembers(category: String): WikiApiCategoryResponse
    /** Articles + subcategories of [category] in one call; pass the previous [cont] to page on. */
    suspend fun getCategoryChildren(category: String, cont: WikiContinue? = null): WikiApiCategoryResponse
    /** Pixel sizes of the picture files [titles] ("File:Name.jpg", 50 per call). */
    suspend fun getImageSizes(titles: List<String>): WikiApiImageInfoResponse
    /** Plain-text introductions of [titles] (20 per call). */
    suspend fun getIntros(titles: List<String>): WikiApiIntroResponse
    /** One page (50) of full-text search results starting at [offset]. */
    suspend fun searchArticlesPaged(query: String, offset: Int): WikiApiCategorySearchResponse
    /** Views of the last 30 days for [titles] (50 per call). */
    suspend fun getPageViews(titles: List<String>): WikiApiPageViewsResponse
    /** Sizes of categories; [categories] are bare names without the "Category:" prefix. */
    suspend fun getCategoryInfo(categories: List<String>): WikiApiCategoryInfoResponse
    /** Full-text article search (top 25 titles). */
    suspend fun searchArticleTitles(query: String): WikiApiCategorySearchResponse
    /** Visible categories of [titles] (keep to ~10 titles per call). */
    suspend fun getPageCategories(titles: List<String>): WikiApiPageInfoResponse
    /** Searches category pages by name; titles come back as "Category:Name". */
    suspend fun searchCategoryNames(query: String): WikiApiCategorySearchResponse
    /** Returns only subcategories of [category] — used for the random-walk traversal strategy. */
    suspend fun getCategorySubcats(category: String): WikiApiCategoryResponse
    /**
     * @param sort `"relevance"` (default) or `"incoming_links_desc"` for popularity-ranked results.
     */
    suspend fun searchInCategory(
        category: String,
        offset: Int = 0,
        limit: Int = 200,
        sort: String = "relevance"
    ): WikiApiCategorySearchResponse
    /**
     * Batch page-info lookup for stub detection.
     * [titles] is a list of article titles (batched internally in groups of 50).
     */
    suspend fun getPageInfo(titles: List<String>): WikiApiPageInfoResponse
    suspend fun getFeed(
        date: String = LocalDate.now()
            .format(DateTimeFormatter.ofPattern("yyyy/MM/dd"))
    ): FeedApiResponse
}

class NetworkWikipediaRepository(
    private val wikipediaApiService: WikipediaApiService,
    private val wikipediaPageApiService: WikipediaApiService,
    private val ioDispatcher: CoroutineDispatcher
) : WikipediaRepository {
    override suspend fun getPrefixSearchResults(query: String): WikiApiPrefixSearchResults =
        withContext(ioDispatcher) {
            wikipediaApiService.getPrefixSearchResults(query)
        }

    override suspend fun getSearchResults(query: String): WikiApiSearchResults =
        withContext(ioDispatcher) {
            wikipediaApiService.getSearchResults(query)
        }

    override suspend fun getPageData(query: String): WikiApiPageData =
        withContext(ioDispatcher) {
            wikipediaApiService.getPageData(query)
        }

    override suspend fun getPageContent(title: String): String =
        withContext(ioDispatcher) {
            wikipediaPageApiService.getPageContent(title)
        }

    override suspend fun getPageHtml(title: String): String =
        withContext(ioDispatcher) {
            wikipediaPageApiService.getPageHtml(title)
        }

    override suspend fun getRandomResult(): WikiApiPageData =
        withContext(ioDispatcher) {
            wikipediaApiService.getRandomResult()
        }

    override suspend fun getCategoryMembers(category: String): WikiApiCategoryResponse =
        withContext(ioDispatcher) {
            wikipediaApiService.getCategoryMembers("Category:$category")
        }

    override suspend fun getCategoryChildren(
        category: String,
        cont: WikiContinue?
    ): WikiApiCategoryResponse =
        withContext(ioDispatcher) {
            wikipediaApiService.getCategoryChildren("Category:$category", cont?.cont, cont?.cmcontinue)
        }

    override suspend fun getImageSizes(titles: List<String>): WikiApiImageInfoResponse =
        withContext(ioDispatcher) { wikipediaApiService.getImageSizes(titles.joinToString("|")) }

    override suspend fun getIntros(titles: List<String>): WikiApiIntroResponse =
        withContext(ioDispatcher) { wikipediaApiService.getIntros(titles.joinToString("|")) }

    override suspend fun searchArticlesPaged(query: String, offset: Int): WikiApiCategorySearchResponse =
        withContext(ioDispatcher) { wikipediaApiService.searchArticlesPaged(query, offset) }

    override suspend fun getPageViews(titles: List<String>): WikiApiPageViewsResponse =
        withContext(ioDispatcher) { wikipediaApiService.getPageViews(titles.joinToString("|")) }

    override suspend fun getCategoryInfo(categories: List<String>): WikiApiCategoryInfoResponse =
        withContext(ioDispatcher) {
            wikipediaApiService.getCategoryInfo(categories.joinToString("|") { "Category:$it" })
        }

    override suspend fun searchArticleTitles(query: String): WikiApiCategorySearchResponse =
        withContext(ioDispatcher) { wikipediaApiService.searchArticleTitles(query) }

    override suspend fun getPageCategories(titles: List<String>): WikiApiPageInfoResponse =
        withContext(ioDispatcher) { wikipediaApiService.getPageCategories(titles.joinToString("|")) }

    override suspend fun searchCategoryNames(query: String): WikiApiCategorySearchResponse =
        withContext(ioDispatcher) {
            wikipediaApiService.searchCategoryNames(query)
        }

    override suspend fun getCategorySubcats(category: String): WikiApiCategoryResponse =
        withContext(ioDispatcher) {
            wikipediaApiService.getCategorySubcats("Category:$category")
        }

    override suspend fun searchInCategory(
        category: String,
        offset: Int,
        limit: Int,
        sort: String
    ): WikiApiCategorySearchResponse =
        withContext(ioDispatcher) {
            wikipediaApiService.searchInCategory(
                query = "incategory:\"${category.replace('_', ' ')}\"",
                offset = offset,
                limit = limit,
                sort = sort
            )
        }

    override suspend fun getPageInfo(titles: List<String>): WikiApiPageInfoResponse =
        withContext(ioDispatcher) {
            // MediaWiki accepts up to 50 titles per prop=info call; caller batches if needed
            wikipediaApiService.getPageInfo(titles.joinToString("|"))
        }

    override suspend fun getFeed(date: String): FeedApiResponse =
        withContext(ioDispatcher) {
            wikipediaApiService.getFeed(date)
        }
}
