package org.nsh07.wikireader.shared

import kotlin.test.Test
import kotlin.test.assertEquals
import kotlin.test.assertTrue

class WikiUrlsTest {
    @Test
    fun normalizesSpacesAndRepeatedUnderscores() {
        assertEquals("Athyrium_filix-femina", WikiUrls.normalizeTitle("  Athyrium  filix-femina "))
        assertEquals("Main_Page", WikiUrls.normalizeTitle("Main__Page"))
    }

    @Test
    fun encodesUnicodeAndReservedCharacters() {
        assertEquals("Caf%C3%A9", WikiUrls.encodeTitle("Café"))
        assertEquals("A%26B", WikiUrls.encodeTitle("A&B"))
        assertEquals("100%25", WikiUrls.encodeTitle("100%"))
    }

    @Test
    fun articleUrlsUseTheRequestedLanguage() {
        assertEquals(
            "https://de.wikipedia.org/wiki/K%C3%B6ln",
            WikiUrls.articleUrl("DE", " Köln ")
        )
        assertEquals(
            "https://en.m.wikipedia.org/wiki/Main_Page",
            WikiUrls.mobileArticleUrl("en", "Main Page")
        )
    }

    @Test
    fun articleToolUrlsUseMediaWikiConventions() {
        assertEquals(
            "https://en.wikipedia.org/wiki/Talk%3ACaf%C3%A9",
            WikiUrls.talkPageUrl("en", "Café")
        )
        assertEquals(
            "https://en.wikipedia.org/w/index.php?title=Caf%C3%A9&action=history",
            WikiUrls.historyUrl("en", "Café")
        )
        assertTrue(WikiUrls.whatLinksHereUrl("en", "Café").endsWith("/Caf%C3%A9"))
    }

    @Test
    fun fileUrlsSupportOptionalResizeWidth() {
        assertEquals(
            "https://en.wikipedia.org/wiki/Special:FilePath/Example.jpg",
            WikiUrls.filePathUrl("en", "File:Example.jpg")
        )
        assertTrue(
            WikiUrls.filePathUrl("en", "Example.jpg", 640)
                .endsWith("?width=640")
        )
    }

    @Test
    fun categoryMembersUrlIsReadyForTopicDiscovery() {
        assertEquals(
            "https://en.wikipedia.org/w/api.php?action=query&list=categorymembers" +
                "&cmtitle=Category%3AOrchids&cmtype=page&cmnamespace=0" +
                "&cmlimit=50&format=json&formatversion=2",
            WikiUrls.categoryMembersUrl("en", "Orchids")
        )
        assertTrue(
            WikiUrls.categoryMembersUrl("de", "Rosen & Verwandte", limit = 20)
                .contains("cmlimit=20")
        )
    }

    @Test
    fun searchApiUrlUsesGeneratorSearchAndEncodesQuery() {
        assertEquals(
            "https://en.wikipedia.org/w/api.php?action=query&generator=search" +
                "&gsrsearch=black%20hole&gsrnamespace=0&gsrlimit=20" +
                "&gsrprop=snippet|titlesnippet|redirecttitle" +
                "&prop=pageimages&piprop=thumbnail&pithumbsize=250" +
                "&format=json&formatversion=2",
            WikiUrls.searchApiUrl("en", " black hole ")
        )
        assertTrue(
            WikiUrls.searchApiUrl("de", "Köln", limit = 5)
                .contains("gsrsearch=K%C3%B6ln")
        )
    }

    @Test
    fun textHelpersAreUsefulForCards() {
        assertEquals("Hello world", WikiText.plainText("<b>Hello</b>&nbsp;world"))
        assertEquals(1, WikiText.readingMinutes("one two three", wordsPerMinute = 3))
        assertTrue(WikiText.snippet("A sentence. Another sentence.", maxChars = 12).endsWith("…"))
    }
}
