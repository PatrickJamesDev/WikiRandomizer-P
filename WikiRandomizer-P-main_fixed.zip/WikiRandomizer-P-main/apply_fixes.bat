@echo off
REM ============================================================================
REM  WikiRandomizer-P - apply_fixes.bat
REM  Put this file in the project root (next to gradlew.bat) and double-click it.
REM  Safe to run repeatedly; each patch is skipped if already applied, and every
REM  file it changes is first copied to FILE.bak (only once).
REM
REM  1. Build: ':app:extractDebugNativeSymbolTables' failed with
REM     "Could not get file mode for ...libzim_wrapper.so.sym" (Gradle build cache
REM     can't pack that output on Windows) - those tasks are excluded from the cache.
REM  2. Build: Kotlin "Default Hierarchy Template Not Applied" warning: shared/
REM     build.gradle.kts uses the built-in iosMain (configured lazily).
REM  3. UI: Tabs panel now moves like the left navigation drawer (Material spatial
REM     spring motion, tab list no longer recomposes when the panel settles).
REM  4. UI/a11y: the closed Tabs panel is hidden from TalkBack (it used to expose its
REM     off-screen tab list, unlike the left drawer).
REM  5. build_windows.bat: build_errors.txt now contains the actual cause (the
REM     "Failed to ..." lines under "What went wrong"), and build_log.txt no
REM     longer fills with "System.Management.Automation.RemoteException" lines.
REM ============================================================================
setlocal
cd /d "%~dp0"
if not exist "app\build.gradle.kts" (
  echo ERROR: run this from the project root ^(app\build.gradle.kts not found^).
  pause & exit /b 1
)
set "FIX_ROOT=%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s = Get-Content -LiteralPath '%~f0' -Raw; Invoke-Expression ($s -split ('#PS_'+'START'))[1]"
if errorlevel 1 ( echo. & echo Patch step failed - nothing further was changed. & pause & exit /b 1 )

echo.
echo Stopping Gradle daemons (releases locked files)...
call gradlew.bat --stop >nul 2>&1

echo Deleting stale native symbol table output...
if exist "app\build\intermediates\native_symbol_tables" rmdir /s /q "app\build\intermediates\native_symbol_tables"
if exist "app\build\intermediates\native_symbol_tables" (
  echo   Could not delete it - close Android Studio / pause antivirus scanning of the folder and rerun.
)

echo.
echo Done. Now rebuild with build_windows.bat (or gradlew.bat :app:assembleDebug).
echo If it STILL fails on the .sym file, exclude the project folder from Windows Defender
echo or move it to a shorter path such as C:\dev\WikiRandomizer.
pause
exit /b 0

#PS_START
$ErrorActionPreference = 'Stop'
$root = $env:FIX_ROOT
$utf8 = New-Object System.Text.UTF8Encoding($false)

function N([string]$s) { return $s.Replace("`r`n", "`n") }
function Backup([string]$path) { if (-not (Test-Path -LiteralPath ($path + '.bak'))) { Copy-Item -LiteralPath $path -Destination ($path + '.bak') } }
function Rep([string]$text, [string]$old, [string]$new, [string]$what) {
    if (-not $text.Contains($old)) { throw ('pattern not found: ' + $what) }
    return $text.Replace($old, $new)
}

# ---- 1. app/build.gradle.kts: keep native-symbol-table tasks out of the build cache
$appFile = Join-Path $root 'app\build.gradle.kts'
$app = [IO.File]::ReadAllText($appFile)
if (-not $app.Contains('NativeSymbolTables')) {
    Backup $appFile
    $block = N @'


// --- build fix: AGP's extract*NativeSymbolTables output (libzim/libkiwix .sym files) can't be
// packed into the Gradle build cache on Windows ("Could not get file mode for ...so.sym").
// The task is fast, so simply don't cache it.
tasks.matching { it.name.startsWith("extract") && it.name.endsWith("NativeSymbolTables") }
    .configureEach { outputs.cacheIf { false } }
'@
    $eol = "`n"; if ($app.Contains("`r`n")) { $eol = "`r`n" }
    $app = $app.TrimEnd() + $block.Replace("`n", $eol) + $eol
    [IO.File]::WriteAllText($appFile, $app, $utf8)
    Write-Host '[ok]   app\build.gradle.kts'
} else { Write-Host '[skip] app\build.gradle.kts already patched' }

# ---- 2. shared/build.gradle.kts: default hierarchy template's iosMain, configured lazily
$shFile = Join-Path $root 'shared\build.gradle.kts'
$sh = [IO.File]::ReadAllText($shFile)
if (-not $sh.Contains('matching { it.name == "iosMain" }')) {
    Backup $shFile
    $new = N @'
// iosMain comes from the default hierarchy template, which Kotlin applies only after this
        // block has been evaluated, so configure it lazily when it appears.
        matching { it.name == "iosMain" }.configureEach {
            dependencies {
                implementation(compose.foundation)
                implementation(compose.material3)
                implementation(compose.ui)
            }
        }
'@
    $new = $new.TrimEnd()
    $p1 = '(?s)val iosMain by creating \{.*?dependsOn\(iosMain\)\s*\}'
    $p2 = '(?s)(//[^\n]*\n\s*)?getByName\("iosMain"\)\.dependencies \{[^}]*\}'
    $out = [regex]::Replace($sh, $p1, { param($m) $new })
    if ($out -eq $sh) { $out = [regex]::Replace($sh, $p2, { param($m) $new }) }
    if ($out -eq $sh) { throw 'shared\build.gradle.kts: pattern did not match' }
    [IO.File]::WriteAllText($shFile, $out.TrimEnd() + "`n", $utf8)
    Write-Host '[ok]   shared\build.gradle.kts'
} else { Write-Host '[skip] shared\build.gradle.kts already patched' }

# ---- 3 + 4. AppScreen.kt: Tabs panel motion, recomposition, closed-panel semantics
$asFile = Join-Path $root 'app\src\main\java\com\wikirandomizerp\app\ui\AppScreen.kt'
$raw = [IO.File]::ReadAllText($asFile)
if (-not $raw.Contains('ArticleTabPanelContent')) {
    Backup $asFile
    $crlf = $raw.Contains("`r`n")
    $t = N $raw
    $lines = [System.Collections.Generic.List[string]]($t -split "`n")

    # locate the sheet content that sits inside ModalDrawerSheet { ... }
    $start = -1; $end = -1
    for ($i = 0; $i -lt $lines.Count; $i++) {
        $s = $lines[$i].Trim()
        if ($start -lt 0 -and $s -eq 'val showLanguage = remember(tabs) { tabs.map { it.lang }.distinct().size > 1 }') { $start = $i }
        if ($start -ge 0 -and $s.StartsWith('// No permanent handle')) { $end = $i; break }
    }
    if ($start -lt 0 -or $end -lt 0) { throw 'AppScreen.kt: tab panel content not found (file differs from the expected version)' }
    $j = $end - 1
    while ($lines[$j].Trim() -eq '') { $j-- }
    if ($lines[$j] -ne '        }' -or $lines[$j - 1] -ne '        }') { throw 'AppScreen.kt: unexpected tab panel structure' }

    $body = New-Object System.Collections.Generic.List[string]
    for ($i = $start; $i -le $j - 2; $i++) {
        $ln = $lines[$i]
        if ($ln.StartsWith('        ')) { $ln = $ln.Substring(8) }
        $body.Add($ln)
    }

    $callText = N @'
            // The sheet's content lives in its own function so flipping `open` (which happens
            // when a drag or animation settles) does not re-compose the whole tab list.
            ArticleTabPanelContent(
                tabs = tabs,
                activeTabId = activeTabId,
                canGoBack = canGoBack,
                canGoForward = canGoForward,
                canOpenInBrowser = canOpenInBrowser,
                imageSearchTitle = imageSearchTitle,
                onFindImages = onFindImages,
                onOpenInBrowser = onOpenInBrowser,
                onBack = onBack,
                onForward = onForward,
                onSelectTab = onSelectTab,
                onCloseTab = onCloseTab,
                onNewTab = onNewTab,
                recentlyClosed = recentlyClosed,
                onReopenClosedTab = onReopenClosedTab,
                onOpenChange = onOpenChange
            )
'@
    $out = New-Object System.Collections.Generic.List[string]
    for ($i = 0; $i -lt $start; $i++) { $out.Add($lines[$i]) }
    foreach ($c in ($callText.TrimEnd() -split "`n")) { $out.Add($c) }
    for ($i = $j - 1; $i -lt $lines.Count; $i++) { $out.Add($lines[$i]) }
    $t = $out -join "`n"

    $funcHead = N @'
/** The tab panel's list, back/forward row and shortcuts. Separate so it can skip recomposition. */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalMaterial3ExpressiveApi::class)
@Composable
private fun ColumnScope.ArticleTabPanelContent(
    tabs: List<ArticleTab>,
    activeTabId: Long?,
    canGoBack: Boolean,
    canGoForward: Boolean,
    canOpenInBrowser: Boolean,
    imageSearchTitle: String?,
    onFindImages: (String) -> Unit,
    onOpenInBrowser: () -> Unit,
    onBack: () -> Unit,
    onForward: () -> Unit,
    onSelectTab: (Long) -> Unit,
    onCloseTab: (Long) -> Unit,
    onNewTab: () -> Unit,
    recentlyClosed: List<ArticleTab>,
    onReopenClosedTab: () -> Unit,
    onOpenChange: (Boolean) -> Unit
) {
'@
    $func = $funcHead + ($body -join "`n") + "`n}`n`n"
    $marker = '/**' + "`n" + ' * The confirmation for "a link was held'
    $t = Rep $t $marker ($func + $marker) 'TabAddedFlash marker'

    # same motion as the left navigation drawer
    $t = Rep $t (N @'
    val density = LocalDensity.current
    val dragState = remember {
        AnchoredDraggableState(initialValue = TabPanelValue.Closed)
    }
'@) (N @'
    val density = LocalDensity.current
    // Same motion the left navigation drawer uses (Material's spatial spring to open and to settle
    // a drag, the fast effects spec to close), instead of a fixed 260 ms tween.
    val panelMotion = MaterialTheme.motionScheme
    val settleSpec = panelMotion.defaultSpatialSpec<Float>()
    val closeSpec = panelMotion.fastEffectsSpec<Float>()
    val dragState = remember {
        AnchoredDraggableState(initialValue = TabPanelValue.Closed)
    }
'@) 'drag state'
    $t = Rep $t "        { distance -> distance * 0.5f },`n        tween(260)`n    )" "        { distance -> distance * 0.5f },`n        settleSpec`n    )" 'fling spec'
    $t = Rep $t 'dragState.animateTo(target)' 'dragState.animateTo(target, if (open) settleSpec else closeSpec)' 'animateTo'
    $t = Rep $t "import androidx.compose.foundation.layout.Column`n" "import androidx.compose.foundation.layout.Column`nimport androidx.compose.foundation.layout.ColumnScope`n" 'import'
    # closed panel: hide the off-screen tab list from accessibility services
    $t = Rep $t "flingBehavior = stableFling`n                    ) else Modifier`n" "flingBehavior = stableFling`n                    ) else Modifier.clearAndSetSemantics {}`n" 'closed semantics'

    if ($crlf) { $t = $t.Replace("`n", "`r`n") }
    [IO.File]::WriteAllText($asFile, $t, $utf8)
    Write-Host '[ok]   AppScreen.kt'
} else { Write-Host '[skip] AppScreen.kt already patched' }

# ---- 5. build_windows.bat: readable log + real error cause in build_errors.txt
$bwFile = Join-Path $root 'build_windows.bat'
if (Test-Path -LiteralPath $bwFile) {
    $bw = [IO.File]::ReadAllText($bwFile)
    $oldRun = '& .\gradlew.bat %TASK% --no-configuration-cache --console=plain 2>&1 | ForEach-Object'
    $newRun = "& cmd /c '.\gradlew.bat %TASK% --no-configuration-cache --console=plain 2>&1' | ForEach-Object"
    $oldFind = 'findstr /B /C:"e: " /C:"error:" /C:"* What went wrong" /C:"Execution failed" /C:"Caused by" build_log.txt > build_errors.txt'
    $newFind = @'
powershell -NoProfile -Command "$lg=@(Get-Content -LiteralPath 'build_log.txt'); $o=New-Object System.Collections.Generic.List[string]; for($i=0;$i -lt $lg.Count;$i++){ $t=[string]$lg[$i]; if($t.StartsWith('e: ') -or $t.StartsWith('error:') -or $t.StartsWith('Caused by')){ $o.Add($t) } elseif($t.StartsWith('* What went wrong')){ $o.Add($t); for($j=$i+1;$j -lt $lg.Count -and -not ([string]$lg[$j]).StartsWith('* Try:');$j++){ if(([string]$lg[$j]).Trim() -ne ''){ $o.Add([string]$lg[$j]) } } } }; $o | Set-Content -LiteralPath 'build_errors.txt' -Encoding UTF8"
'@
    $newFind = $newFind.Trim()
    if ($bw.Contains($oldRun) -and $bw.Contains($oldFind)) {
        Backup $bwFile
        $bw = $bw.Replace($oldRun, $newRun).Replace($oldFind, $newFind)
        [IO.File]::WriteAllText($bwFile, $bw, $utf8)
        Write-Host '[ok]   build_windows.bat'
    } else { Write-Host '[skip] build_windows.bat (already patched or different)' }
}
