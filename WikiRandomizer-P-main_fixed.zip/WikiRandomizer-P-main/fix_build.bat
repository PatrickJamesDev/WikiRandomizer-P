@echo off
REM ============================================================================
REM  WikiRandomizer-P build fixer.  Put this file in the project root (next to
REM  gradlew.bat) and double-click it.  Safe to run more than once.
REM
REM  Fixes:
REM   1. ':app:extractDebugNativeSymbolTables' FAILED
REM      "Failed to store cache entry ... Could not get file mode for
REM       ...\x86\libzim_wrapper.so.sym"
REM      -> the Gradle build cache can't pack that task's output on Windows.
REM         The task is excluded from the build cache (it's cheap to re-run).
REM         Stale native_symbol_tables output is deleted and daemons stopped.
REM   2. Kotlin "Default Hierarchy Template Not Applied Correctly" warning
REM      -> shared/build.gradle.kts: manual iosMain/dependsOn wiring replaced by
REM         the built-in iosMain source set.
REM ============================================================================
setlocal
cd /d "%~dp0"
if not exist "app\build.gradle.kts" (
  echo ERROR: run this from the project root ^(app\build.gradle.kts not found^).
  pause & exit /b 1
)
set "FIX_ROOT=%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s = Get-Content -LiteralPath '%~f0' -Raw; Invoke-Expression ($s -split ('#PS_'+'START'))[1]"
if errorlevel 1 ( echo Patch step failed. & pause & exit /b 1 )

echo.
echo Stopping Gradle daemons (releases locked files)...
call gradlew.bat --stop >nul 2>&1

echo Deleting stale native symbol table output...
if exist "app\build\intermediates\native_symbol_tables" rmdir /s /q "app\build\intermediates\native_symbol_tables"
if exist "app\build\intermediates\native_symbol_tables" (
  echo   Could not delete it - close Android Studio / antivirus scanning of the folder and rerun.
)

echo.
echo Done. Now rebuild, e.g.:  gradlew.bat :app:assembleDebug
echo If it STILL fails on the .sym file, add the project folder to Windows Defender
echo exclusions (or move it to a shorter path such as C:\dev\WikiRandomizer).
pause
exit /b 0

#PS_START
$ErrorActionPreference = 'Stop'
$root = $env:FIX_ROOT
$utf8 = New-Object System.Text.UTF8Encoding($false)

# ---- 1. app/build.gradle.kts: keep native-symbol-table tasks out of the build cache
$appFile = Join-Path $root 'app\build.gradle.kts'
$app = [IO.File]::ReadAllText($appFile)
if ($app -notmatch 'NativeSymbolTables') {
    $block = @'


// --- build fix: AGP's extract*NativeSymbolTables output (libzim/libkiwix .sym files) can't be
// packed into the Gradle build cache on Windows ("Could not get file mode for ...so.sym").
// The task is fast, so simply don't cache it.
tasks.matching { it.name.startsWith("extract") && it.name.endsWith("NativeSymbolTables") }
    .configureEach { outputs.cacheIf { false } }
'@
    [IO.File]::WriteAllText($appFile, $app.TrimEnd() + $block + "`n", $utf8)
    Write-Host '[ok] patched app\build.gradle.kts'
} else { Write-Host '[skip] app\build.gradle.kts already patched' }

# ---- 2. shared/build.gradle.kts: use the default hierarchy template's iosMain.
# The template is applied only AFTER the kotlin {} block finishes, so iosMain cannot be looked up
# eagerly (getByName fails with "KotlinSourceSet 'iosMain' not found"). Configure it lazily.
$shFile = Join-Path $root 'shared\build.gradle.kts'
$sh = [IO.File]::ReadAllText($shFile)
if ($sh -notmatch 'matching \{ it\.name == "iosMain" \}') {
    $new = @'
// iosMain comes from the default hierarchy template, which Kotlin applies only after this
        // block has been evaluated, so configure it lazily when it appears.
        matching { it.name == "iosMain" }.configureEach {
            dependencies {
                implementation(compose.foundation)
                implementation(compose.material3)
                implementation(compose.ui)
            }
        }
'@
    $p1 = '(?s)val iosMain by creating \{.*?dependsOn\(iosMain\)\s*\}'            # original file
    $p2 = '(?s)(//[^\n]*\n\s*)?getByName\("iosMain"\)\.dependencies \{[^}]*\}'     # earlier version of this fix
    $out = [regex]::Replace($sh, $p1, { param($m) $new })
    if ($out -eq $sh) { $out = [regex]::Replace($sh, $p2, { param($m) $new }) }
    if ($out -eq $sh) { throw 'shared\build.gradle.kts: pattern did not match' }
    [IO.File]::WriteAllText($shFile, $out.TrimEnd() + "`n", $utf8)
    Write-Host '[ok] patched shared\build.gradle.kts'
} else { Write-Host '[skip] shared\build.gradle.kts already patched' }