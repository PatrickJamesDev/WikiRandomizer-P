@echo off
REM ============================================================================
REM  WikiRandomizer-P - repair_gradle_cache.bat
REM  Fixes builds that die while Gradle is creating tasks, e.g.
REM    "Could not generate a decorated class for type KotlinCompile.
REM       org/jetbrains/kotlin/daemon/common/MultiModuleICSettings"
REM  That is a class missing from a Gradle plugin jar, which happens when an earlier
REM  build was killed or blocked while Gradle wrote its generated/cached plugin jars.
REM  This script: stops the daemons, deletes Gradle's generated plugin jars (rebuilt
REM  automatically), deletes any truncated/corrupt Kotlin/KSP/Compose/AGP jars from the
REM  dependency cache, forgets Gradle's cached resolution metadata so those jars are
REM  re-downloaded on the next build, and clears the project's
REM  .gradle and .kotlin folders.  Safe to run any time.  build_windows.bat runs it
REM  automatically (once) when it sees this error.
REM  Usage: repair_gradle_cache.bat        (add the word nopause to skip the pause)
REM ============================================================================
setlocal
cd /d "%~dp0"
set "FIX_ROOT=%~dp0"
echo Stopping Gradle daemons...
if exist gradlew.bat call gradlew.bat --stop >nul 2>&1
powershell -NoProfile -ExecutionPolicy Bypass -Command "$s = Get-Content -LiteralPath '%~f0' -Raw; Invoke-Expression ($s -split ('#PS_'+'START'))[1]"
echo.
echo Cache repair finished. The next build re-downloads whatever was removed.
if /i not "%~1"=="nopause" pause
exit /b 0

#PS_START
$ErrorActionPreference = 'Continue'
$gh = $env:GRADLE_USER_HOME
if (-not $gh) { $gh = Join-Path $env:USERPROFILE '.gradle' }
$caches = Join-Path $gh 'caches'
Write-Host ('Gradle user home: ' + $gh)

function Drop([string]$p) {
    if (Test-Path -LiteralPath $p) {
        try { Remove-Item -LiteralPath $p -Recurse -Force -ErrorAction Stop; Write-Host ('[ok]   removed ' + $p) }
        catch { Write-Host ('[warn] could not remove ' + $p + ' - close Android Studio and rerun. ' + $_.Exception.Message) }
    }
}

if (Test-Path -LiteralPath $caches) {
    # 1. generated / instrumented plugin jars: always rebuilt by Gradle
    foreach ($d in (Get-ChildItem -LiteralPath $caches -Directory -ErrorAction SilentlyContinue)) {
        if ($d.Name -like 'jars-*') { Drop $d.FullName }
        elseif ($d.Name -match '^\d+\.\d+') { Drop (Join-Path $d.FullName 'generated-gradle-jars') }
    }

    # 2. truncated or corrupt jars in the dependency cache
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $mod = Join-Path $caches 'modules-2\files-2.1'
    $checked = 0; $bad = 0
    if (Test-Path -LiteralPath $mod) {
        $groups = Get-ChildItem -LiteralPath $mod -Directory -ErrorAction SilentlyContinue | Where-Object {
            $_.Name -like 'org.jetbrains*' -or $_.Name -like 'com.google.devtools.ksp*' -or
            $_.Name -like 'com.android.tools*' -or $_.Name -like 'androidx.baselineprofile*'
        }
        foreach ($g in $groups) {
            foreach ($f in (Get-ChildItem -LiteralPath $g.FullName -Recurse -Filter '*.jar' -File -ErrorAction SilentlyContinue)) {
                $checked++
                $ok = ($f.Length -gt 0)
                if ($ok) {
                    # Only a malformed archive counts as corrupt; a locked file is left alone.
                    try { $z = [System.IO.Compression.ZipFile]::OpenRead($f.FullName); $z.Dispose() }
                    catch [System.IO.InvalidDataException] { $ok = $false }
                    catch { }
                }
                if (-not $ok) {
                    $bad++
                    Write-Host ('  corrupt jar: ' + $f.FullName)
                    Drop $f.Directory.FullName
                }
            }
        }
    }
    Write-Host ("Checked $checked jars, removed $bad corrupt.")

    # 3. Forget Gradle's cached resolution results. Without this Gradle still believes a jar
    #    that was removed is present ("Transform output ... must exist") and never re-downloads
    #    it. Resolution metadata is cheap to rebuild; files that are intact are re-used.
    $m2 = Join-Path $caches 'modules-2'
    if (Test-Path -LiteralPath $m2) {
        foreach ($d in (Get-ChildItem -LiteralPath $m2 -Directory -Filter 'metadata-*' -ErrorAction SilentlyContinue)) { Drop $d.FullName }
    }
} else {
    Write-Host 'No Gradle cache found yet.'
}

# 4. project-level caches
$proj = $env:FIX_ROOT
Drop (Join-Path $proj '.gradle')
Drop (Join-Path $proj '.kotlin')
